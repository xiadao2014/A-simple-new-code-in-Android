package cn.lhy.uilt;
import java.util.List;
import java.util.Map;
import cn.lhy.domain.NewsInformationTable;

/**
 * @ClassName: ConstantValue l.hy
 * @Description: 常量类
 * @date 2014-2-5 下午3:25:06
 */
public class ConstantValue {
	public static final String NOT_EXIST = "null";
	/** 测试用值 */
	public static final Boolean isTest = true;
	/** 代理商密码 */
	public static final String AGENT_PASSWORD = "9ab62a694d8bf6ced1fab6acd48d02f8";
	/** des加密用密钥 */
	public static final String DES_KEY = "9b2648fcdfbad80f";

	public static final String PNG_BASE_URL = "http://10.0.2.2:8080/Mycc/";
	public static final String NEWS_IMAGE_URL = PNG_BASE_URL + "news_image/";

	public static Map<Integer, List<NewsInformationTable>> refreshMap;

}
