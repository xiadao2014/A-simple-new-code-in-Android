package cn.lhy.uilt;

import javax.servlet.http.HttpServletRequest;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import cn.lhy.ask.Ask;

public class AskUilt {
	/** MD5加密判断  规则就是访问action和访问方法名加代理商密码*/
	public static boolean isAskMd5(Ask ask) {
		if (ask != null) {
			String md5Info = ask.getMd5Info();
			String decrypt = DESUilt.decrypt(md5Info, ConstantValue.DES_KEY);
			String askMd5 = ask.getAction() + ask.getActionMethod()
					+ ConstantValue.AGENT_PASSWORD;
			if (decrypt.equals(askMd5)) {
				return true;
			}
		}
		return false;
	}

	/** Gson字符串解析成Ask对象，转换字符为DncodeUTF-8编码 ,用于接收后解析处理 */
	public static Ask getAsk(HttpServletRequest request) {
		String parameter = request.getParameter(AskValue.BASE_PARAMS);
		String gsonDncodeStr = GeneralUilt.getGsonDncodeStr(parameter);
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation() // 不导出实体中没有用@Expose注解的属性
				.enableComplexMapKeySerialization() // 支持Map的key为复杂对象的形式
				.serializeNulls().setDateFormat("yyyy-MM-dd HH:mm").create();// 时间转化为特定格式
		Ask ask = gson.fromJson(gsonDncodeStr, Ask.class);
		return ask;
	}
}
