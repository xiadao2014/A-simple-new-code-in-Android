package cn.lhy.uilt;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.LinkedList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import cn.lhy.domain.NewsInformationTable;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GeneralUilt {
	/** 转换对象包装为GsonEncodeStr，转换字符为EncodeUTF-8编码 ,用于发送处理 */
	public static String getGsonEncodeStr(Object o) {
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation() // 不导出实体中没有用@Expose注解的属性
				.enableComplexMapKeySerialization() // 支持Map的key为复杂对象的形式
				.serializeNulls().setDateFormat("yyyy-MM-dd HH:mm").create();// 时间转化为特定格式
		String encodeStr = null;
		try {
			encodeStr = URLEncoder.encode(gson.toJson(o), "utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return encodeStr;
	}

	/** 解析GsonEncodeStr，转换字符正常字符串 ,用于接收处理 */
	public static String getGsonDncodeStr(String gsonEncodeStr) {
		String dncodeStr = null;
		try {
			dncodeStr = URLDecoder.decode(gsonEncodeStr, "utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return dncodeStr;
	}

	public static boolean sendResponseResult(Object targetResult,
			HttpServletResponse response) {
		String sendEcode = getGsonEncodeStr(targetResult);
		try {
			response.getOutputStream().write(sendEcode.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public static boolean sendResponseList(List<?> resultList,
			HttpServletResponse response) {
		String sendEcode = getGsonEncodeStr(resultList);
		try {
			response.getOutputStream().write(sendEcode.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public static boolean sendNotexist(HttpServletResponse response) {
		try {
			response.getOutputStream()
					.write(ConstantValue.NOT_EXIST.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

}
