package cn.lhy.uilt;

import java.util.HashMap;

/**
 * @ClassName: ConstantValue l.hy
 * @Description: 常量类
 * @date 2014-2-5 下午3:25:06
 */
public class AskValue {
	/** 默认paramsKey值 */
	public static final String BASE_PARAMS = "Ask";
	/** 新闻Action标识符 */
	public static final String NEWS_BASE_ACTION = "News";
	/** 新闻ActionMethod标识符 */
	public static final String NEWS_REFRESH = "callRefreshNewsItem";
	public static final String NEWS_BODY_METHOD = "callNewsBody";
	/** 新闻客户端ITEM请求标示 */
	public static final int NEWS_ITEM_GIVEME_1 = 100101;// Item叶子
	public static final int NEWS_ITEM_GIVEME_2 = 100102;
	public static final int NEWS_ITEM_GIVEME_3 = 100103;
	public static final int NEWS_ITEM_GIVEME_4 = 100104;
	public static final int NEWS_ITEM_GIVEME_5 = 100105;
	public static final int NEWS_ITEM_GIVEME_6 = 100106;
	public static final int NEWS_ITEM_GIVEME_7 = 100107;
	public static final int NEWS_ITEM_GIVEME_8 = 100108;
	public static final int NEWS_ITEM_GIVEME_9 = 100109;

	public static HashMap<Integer, Integer> NewsClassifyMap;
	static {
		if (NewsClassifyMap == null) {// 保存类别外键，通过Ask中的取key
			NewsClassifyMap = new HashMap<Integer, Integer>();
			NewsClassifyMap.put(NEWS_ITEM_GIVEME_1, 1);
			NewsClassifyMap.put(NEWS_ITEM_GIVEME_2, 2);
			NewsClassifyMap.put(NEWS_ITEM_GIVEME_3, 3);
			NewsClassifyMap.put(NEWS_ITEM_GIVEME_4, 4);
			NewsClassifyMap.put(NEWS_ITEM_GIVEME_5, 5);
			NewsClassifyMap.put(NEWS_ITEM_GIVEME_6, 6);
			NewsClassifyMap.put(NEWS_ITEM_GIVEME_7, 7);
			NewsClassifyMap.put(NEWS_ITEM_GIVEME_8, 8);
			NewsClassifyMap.put(NEWS_ITEM_GIVEME_9, 9);
		}
	}
}
