package cn.lhy.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import cn.lhy.domain.NewsClassifyTable;
import cn.lhy.domain.NewsInformationTable;

@Repository("UserDAO")
public class UserDAO {
	@Autowired
	@Qualifier("hibernateTemplate")
	private HibernateTemplate template;

	public List<?> isUser(String username, String passwrod) {
		List list = template.find(
				"from CUserTable where u_name = ? and u_password = ?",
				new String[] { username, passwrod });
		return list;
	}
}
