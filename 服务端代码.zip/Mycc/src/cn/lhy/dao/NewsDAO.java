package cn.lhy.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import cn.lhy.domain.NewsClassifyTable;
import cn.lhy.domain.NewsInformationTable;
import cn.lhy.uilt.ConstantValue;

/** 新闻客户端dao层 */
@Repository("NewsDAO")
public class NewsDAO {
	@Autowired
	@Qualifier("hibernateTemplate")
	private HibernateTemplate template;
	private static int classifyCount = 0;

	/**
	 * 新闻插入数据方法 把新闻对象设置相应的外键newsClassify，然后插入
	 */
	public void saveNewsInfo(NewsInformationTable infoEntity, int classifyId)
			throws Exception {
		NewsClassifyTable newsClassify = template.get(NewsClassifyTable.class,
				classifyId);// 获得相应外键
		infoEntity.setClassify(newsClassify);// 保存
		template.save(infoEntity);
	}

	public List<NewsInformationTable> findNewsItem(int ItemId, int size) {
		List find = template
				.find("from NewsInformationTable where classify.news_classify_id = ? ",
						ItemId);
		List subList = find.subList(size, find.size());
		return subList;
	}

	/** 初始化新闻端的方法，此方法负责查询新闻数据 */
	@SuppressWarnings("unchecked")
	public ArrayList<List<NewsInformationTable>> findNewssAll() {
		if (classifyCount == 0) {// 从类别表中获取类别总数 并保存
			classifyCount = template.find("from NewsClassifyTable").size();
		}
		ArrayList<List<NewsInformationTable>> result;// 结果声明
		try {
			result = new ArrayList<List<NewsInformationTable>>();
			for (int i = 1; i < classifyCount + 1; i++) {// 根据类别多少，查询多少子标签
				List<NewsInformationTable> list = (List<NewsInformationTable>) template
						.find("from NewsInformationTable where classify.news_classify_id = ? ",
								i).subList(0, 8);// 外键约束查询，利用for 和 外键约束 一次性完成
				result.add(list);// 加入初始化结果集合
				// 每次初始化数据时，我直接保存刷新数据在map集合中，不需要构建刷新查询;（有缺陷，如果作为真实项目当然是不行的）
				// ArrayList<NewsInformationTable> initlist =
				// (ArrayList<NewsInformationTable>) list
				// .subList(0, 8);// 截取前8条
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return result;
	}
}
