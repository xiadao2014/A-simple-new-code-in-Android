package cn.lhy.ask;

import java.util.Date;

import com.google.gson.annotations.Expose;

public class Ask {
	@Expose
	private String Action;
	@Expose
	private String ActionMethod;
	@Expose
	private Date AskDate;
	@Expose
	private Integer GiveMe;
	@Expose
	private String[] PostInfo;
	@Expose
	private String Md5Info;

	public Ask(String action, String actionMethod, Date askDate, Integer giveMe) {
		super();
		Action = action;
		ActionMethod = actionMethod;
		AskDate = askDate;
		GiveMe = giveMe;
	}

	public String getAction() {
		return Action;
	}

	public void setAction(String action) {
		Action = action;
	}

	public String getActionMethod() {
		return ActionMethod;
	}

	public void setActionMethod(String actionMethod) {
		ActionMethod = actionMethod;
	}

	public Date getAskDate() {
		return AskDate;
	}

	public void setAskDate(Date askDate) {
		AskDate = askDate;
	}

	public Integer getGiveMe() {
		return GiveMe;
	}

	public void setGiveMe(Integer giveMe) {
		GiveMe = giveMe;
	}

	public String[] getPostInfo() {
		return PostInfo;
	}

	public void setPostInfo(String[] postInfo) {
		PostInfo = postInfo;
	}

	public String getMd5Info() {
		return Md5Info;
	}

	public void setMd5Info(String md5Info) {
		Md5Info = md5Info;
	}

	@Override
	public String toString() {
		return "Ask [Action=" + Action + ", ActionMethod=" + ActionMethod
				+ ", AskDate=" + AskDate + ", GiveMe=" + GiveMe + ", PostInfo="
				+ PostInfo + ", Md5Info=" + Md5Info + "]";
	}

}
