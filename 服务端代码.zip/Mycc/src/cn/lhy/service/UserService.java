package cn.lhy.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import cn.lhy.dao.UserDAO;
import cn.lhy.domain.CUserTable;
import cn.lhy.uilt.GeneralUilt;

@Service("UserService")
@Transactional
public class UserService {
	@Autowired
	@Qualifier("UserDAO")
	private UserDAO userDao;

	public void checkUser(HttpServletResponse response, String[] UserInfo) {
		List<?> users = userDao.isUser(UserInfo[0], UserInfo[1]);
		if (users.size()!=0) {
			CUserTable cuser = (CUserTable) users.get(0);
			GeneralUilt.sendResponseResult(cuser, response);
		}
		else {
			GeneralUilt.sendNotexist(response);
		}
	}
}
