package cn.lhy.service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import cn.lhy.dao.NewsDAO;
import cn.lhy.domain.NewsInformationTable;
import cn.lhy.uilt.GeneralUilt;

@Service("NewsService")
@Transactional
public class NewsService {
	@Autowired
	@Qualifier("NewsDAO")
	private NewsDAO NewsDAO;

	public boolean addNewsInfoService(NewsInformationTable infoEntity,
			int classifyId) {
		try {
			NewsDAO.saveNewsInfo(infoEntity, classifyId);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean initNewssService(HttpServletResponse response) {
		try {
			List<List<NewsInformationTable>> findNewssAll = NewsDAO
					.findNewssAll();
			if (findNewssAll != null) {
				GeneralUilt.sendResponseList(findNewssAll, response);
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}

	public boolean refreshNewsItemService(HttpServletResponse response,
			int tiemId, int nowRefreshSize) {

		try {
			List<NewsInformationTable> findNewsItem = NewsDAO.findNewsItem(
					tiemId + 1, nowRefreshSize);
			if (findNewsItem.size() != 0) {
				GeneralUilt.sendResponseList(findNewsItem, response);
				return true;
			} else {
				GeneralUilt.sendNotexist(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}
}
