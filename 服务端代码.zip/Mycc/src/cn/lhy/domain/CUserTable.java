package cn.lhy.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "c_user_table")
public class CUserTable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int u_id;
	private String u_name, u_password;

	public CUserTable(String u_name, String u_password) {
		super();
		this.u_name = u_name;
		this.u_password = u_password;
	}

	public CUserTable() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getU_id() {
		return u_id;
	}

	public void setU_id(int u_id) {
		this.u_id = u_id;
	}

	public String getU_name() {
		return u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

	public String getU_password() {
		return u_password;
	}

	public void setU_password(String u_password) {
		this.u_password = u_password;
	}

	@Override
	public String toString() {
		return "CUserTable [u_id=" + u_id + ", u_name=" + u_name
				+ ", u_password=" + u_password + "]";
	}

}
