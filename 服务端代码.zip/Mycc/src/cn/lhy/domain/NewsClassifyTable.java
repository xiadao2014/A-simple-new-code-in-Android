package cn.lhy.domain;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Table(name = "news_classify_table")
public class NewsClassifyTable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer news_classify_id;
	private String category;
	// targetEntity 表示一对多对应的类型，mappedBy代表在对应类中的属性名，相当于inverse = true 放弃外键维护权
	@OneToMany(targetEntity = NewsInformationTable.class, mappedBy = "classify", orphanRemoval = true)
	@Cascade(value = { CascadeType.ALL })
	// 配置级联
	private Set<NewsInformationTable> information = new HashSet<NewsInformationTable>();

	public Integer getNews_classify_id() {
		return news_classify_id;
	}

	public void setNews_classify_id(Integer news_classify_id) {
		this.news_classify_id = news_classify_id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Set<NewsInformationTable> getInformation() {
		return information;
	}

	public void setInformation(Set<NewsInformationTable> information) {
		this.information = information;
	}

	@Override
	public String toString() {
		return "NewsClassifyTable [news_classify_id=" + news_classify_id
				+ ", category=" + category 
				+ "]";
	}

}
