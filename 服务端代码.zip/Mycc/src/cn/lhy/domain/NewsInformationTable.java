package cn.lhy.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.google.gson.annotations.Expose;

@Entity
@Table(name = "news_information_table")
public class NewsInformationTable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Expose
	private int news_Information_id;
	@Expose
	private String title_text;// 标头
	@Column(columnDefinition = "TEXT")
	@Expose
	private String middle_text;// 摘要
	@Expose
	private String origin_text;// 时间
	@Expose
	private String img_url;// 图标
	@ManyToOne(targetEntity = NewsClassifyTable.class)
	@JoinColumn(name = "news_classify_id")
	private NewsClassifyTable classify = new NewsClassifyTable();

	public int getNews_Information_id() {
		return news_Information_id;
	}

	public void setNews_Information_id(int news_Information_id) {
		this.news_Information_id = news_Information_id;
	}

	public String getTitle_text() {
		return title_text;
	}

	public void setTitle_text(String title_text) {
		this.title_text = title_text;
	}

	public String getMiddle_text() {
		return middle_text;
	}

	public void setMiddle_text(String middle_text) {
		this.middle_text = middle_text;
	}

	public String getOrigin_text() {
		return origin_text;
	}

	public void setOrigin_text(String origin_text) {
		this.origin_text = origin_text;
	}

	public String getImg_url() {
		return img_url;
	}

	public void setImg_url(String img_url) {
		this.img_url = img_url;
	}

	public NewsClassifyTable getClassify() {
		return classify;
	}

	public void setClassify(NewsClassifyTable classify) {
		this.classify = classify;
	}

	@Override
	public String toString() {
		return "NewsInformationTable [news_Information_id="
				+ news_Information_id + ", title_text=" + title_text
				+ ", middle_text=" + middle_text + ", origin_text="
				+ origin_text + ", img_url=" + img_url + ", classify="
				+ classify + "]";
	}

}
