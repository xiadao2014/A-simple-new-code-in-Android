package cn.lhy.test;

import java.util.List;

import org.apache.commons.collections.ListUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cn.lhy.dao.NewsDAO;
import cn.lhy.domain.CUserTable;
import cn.lhy.domain.NewsClassifyTable;
import cn.lhy.domain.NewsInformationTable;
import cn.lhy.uilt.ConstantValue;
import cn.lhy.web.actions.NewsAction;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class NoteTest {
	@Autowired
	private NewsAction action;
	@Autowired
	@Qualifier("hibernateTemplate")
	private HibernateTemplate template;

	private NewsClassifyTable classify;

	@Test
	public void saveNewsHotspotTest() {
		classify = template.get(NewsClassifyTable.class, 6);
		// classify = new NewsClassifyTable();
		// classify.setCategory("女   人");
		NewsInformationTable info = new NewsInformationTable();
		info.setTitle_text("震惊全球：中国“太空轰炸机”即将亮剑");
		info.setMiddle_text("根据香港媒体报道，中国的太空战机即将揭开面纱。(中国太空轰炸机快亮剑(梁天仞) )而透露这个消息者就是梁天仞。《镜报》全球独家披露中国首艘航母初次试航的准确消息，引发国内外围观。");
		info.setOrigin_text("爱美网");
		info.setImg_url(ConstantValue.NEWS_IMAGE_URL + "news_military_07.jpg");
		info.setClassify(classify);
		// classify.getInformation().add(info);
		template.save(info);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testNewsfindAll() {
		List<NewsInformationTable> list = (List<NewsInformationTable>) template
				.find("from NewsInformationTable where classify.news_classify_id = ? ",
						1).subList(0, 10);
		if (list != null) {
			System.out.println("--------");
		}
	}

	@Test
	public void testNewsfreshItme() {
		// template.find("from CUserTable where u_name = ? and u_password = ?",new
		// String[]{"大屁屁","123"}).get(0);
		// List list =
		// template.find("from CUserTable where u_name = ? and u_password = ?",new
		// String[]{"大屁屁","1234"});
		// if (list.size()==0) {
		// System.out.println("我等于空");
		// }
		// int size = template.find("from NewsClassifyTable").size();
		// System.out.println(size);
	}
}
