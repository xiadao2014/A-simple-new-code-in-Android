package cn.lhy.web.actions;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import cn.lhy.ask.Ask;
import cn.lhy.service.NewsService;
import cn.lhy.uilt.AskUilt;
import cn.lhy.uilt.AskValue;
import cn.lhy.uilt.GeneralUilt;

import com.opensymphony.xwork2.ActionSupport;

@Namespace("/")
@ParentPackage("struts-default")
// 交给Spring来管理
@Controller("News")
// 表明这是c层的，bean
@Scope("prototype")
// 防止线程冲突，这是单例形式
public class NewsAction extends ActionSupport implements ServletRequestAware,
		ServletResponseAware {
	private static final long serialVersionUID = 1L;
	private static Map<Integer, String> ResultMap;
	static {
		ResultMap = new HashMap<Integer, String>();
		ResultMap.put(AskValue.NEWS_ITEM_GIVEME_1, "NewsFocusTable");
		ResultMap.put(AskValue.NEWS_ITEM_GIVEME_2, "NewsInlandTable");
	}
	@Autowired
	@Qualifier("NewsService")
	private NewsService newsService;
	private HttpServletRequest request;
	private HttpServletResponse response;

	@Override
	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	@Action("News")
	public String callInitNews() {
		System.out.println("我来action");
		Ask ask = AskUilt.getAsk(request);
		if (AskUilt.isAskMd5(ask)) {
			int tableEntity = ask.getGiveMe();
			newsService.initNewssService(response);
		}
		return NONE;
	}

	public String callRefreshNewsItem() {
		// TODO 我要刷新
		Ask ask = AskUilt.getAsk(request);
		if (AskUilt.isAskMd5(ask)) {
			int tiemId = ask.getGiveMe();
			int nowRefreshSize = Integer.parseInt(ask.getPostInfo()[0]);
			newsService
					.refreshNewsItemService(response, tiemId, nowRefreshSize);
		} else {
			GeneralUilt.sendNotexist(response);
		}
		return NONE;
	}

	/** 保存一个 */
	public String saveNewsItme() {
		// TODO 我要保存
		return NONE;
	}
}
