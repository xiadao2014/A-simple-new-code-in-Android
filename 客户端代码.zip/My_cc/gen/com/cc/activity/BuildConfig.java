/** Automatically generated file. DO NOT MODIFY */
package com.cc.activity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}