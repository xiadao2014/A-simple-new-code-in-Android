package com.cc.ask;

import java.util.Date;

import com.cc.uilt.AskValue;
import com.cc.uilt.ConstantValue;
import com.cc.uilt.DESUilt;

/** 请求工厂  */
public class AskFactory {
	private static Ask newsInitAsk;

	/** 单例模式获得一个新闻列表请求 */
	public static Ask getInitNewsAsk(Integer itmeLeaf, Date date,
			String[] postInfo) {
		if (newsInitAsk == null) {
			newsInitAsk = new Ask(AskValue.NEWS_BASE_ACTION,
					AskValue.NEWS_INIT, date, itmeLeaf);
			newsInitAsk.setPostInfo(postInfo);
			String askMd5Info = getAskMd5Info(newsInitAsk);
			newsInitAsk.setMd5Info(askMd5Info);
		}
		return newsInitAsk;
	}

	/**  刷新新闻列表的请求构造 */
	public static Ask getRefreshNewsAsk(int NewsItmeId, String [] postInfo) {
		Ask ask = new Ask(AskValue.NEWS_BASE_ACTION, AskValue.NEWS_REFRESH,
				new Date(), NewsItmeId);
		ask.setPostInfo(postInfo);
		String askMd5Info = getAskMd5Info(ask);
		ask.setMd5Info(askMd5Info);
		return ask;
	}
	/**  用户登录请求构造 */
	public static Ask getIsUserAsk(String [] post) {
		Ask ask = new Ask(AskValue.USER_BASE_ASK, AskValue.USER_EXIST,
				new Date(), null);
		ask.setPostInfo(post);
		String askMd5Info = getAskMd5Info(ask);
		ask.setMd5Info(askMd5Info);
		return ask;
	}

	/**  MD5加密构造  */
	private static String getAskMd5Info(Ask ask) {
		String a = ask.getAction() + ask.getActionMethod()
				+ ConstantValue.AGENT_PASSWORD;
		String Md5info = DESUilt.encrypt(a, ConstantValue.DES_KEY);
		return Md5info;
	}
}
