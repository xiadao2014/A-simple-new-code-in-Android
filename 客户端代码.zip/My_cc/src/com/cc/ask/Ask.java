package com.cc.ask;

import java.util.Date;

import com.google.gson.annotations.Expose;

/** 请求实体类 */
public class Ask {
	@Expose
	private String Action;// Action指定标示
	@Expose
	private String ActionMethod;// 访问Action指定方法
	@Expose
	private Date AskDate;// 访问时间
	@Expose
	private Integer GiveMe;// 子请求标识
	@Expose
	private String[] PostInfo;// 需要提交的数据
	@Expose
	private String Md5Info;// 加密信息

	public Ask(String action, String actionMethod, Date askDate, Integer giveMe) {
		super();
		Action = action;
		ActionMethod = actionMethod;
		AskDate = askDate;
		GiveMe = giveMe;
	}

	public String getAction() {
		return Action;
	}

	public void setAction(String action) {
		Action = action;
	}

	public String getActionMethod() {
		return ActionMethod;
	}

	public void setActionMethod(String actionMethod) {
		ActionMethod = actionMethod;
	}

	public Date getAskDate() {
		return AskDate;
	}

	public void setAskDate(Date askDate) {
		AskDate = askDate;
	}

	public Integer getGiveMe() {
		return GiveMe;
	}

	public void setGiveMe(Integer giveMe) {
		GiveMe = giveMe;
	}

	public String[] getPostInfo() {
		return PostInfo;
	}

	public void setPostInfo(String[] postInfo) {
		PostInfo = postInfo;
	}

	public String getMd5Info() {
		return Md5Info;
	}

	public void setMd5Info(String md5Info) {
		Md5Info = md5Info;
	}

	@Override
	public String toString() {
		return "Ask [Action=" + Action + ", ActionMethod=" + ActionMethod
				+ ", AskDate=" + AskDate + ", GiveMe=" + GiveMe + ", PostInfo="
				+ PostInfo + ", Md5Info=" + Md5Info + "]";
	}

}
