package com.cc.manager;

import java.lang.reflect.Constructor;
import java.util.Observable;

import com.cc.activity.R;
import com.cc.fragment.BaseFragment;
import com.cc.uilt.ConstantValue;
import com.cc.uilt.GeneralUilt;

import android.app.Activity;
import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.widget.RelativeLayout;

/**
 * @ClassName: FragmentMg l.hy
 * @Description: 中间切片布局管理者
 * @date 2014-2-5 下午2:54:46
 */
public class FragmentMg extends Observable {
	private static final String TAG = "FragmentMg";
	/**
	 * 切片布局实现观察者模式，实现顶部、底部导航的灵动 切片管理者、切片事务者声明
	 */
	private RelativeLayout main_middle_fragment;// 中间切片容器声明
	private FragmentManager fragmentManager;
	private FragmentTransaction fragmentTransaction;
	/** 切片管理者单例模式实现 */
	private static FragmentMg instrance;

	private FragmentMg() {
	}

	public static FragmentMg getInstrance() {
		if (instrance == null) {
			instrance = new FragmentMg();
			return instrance;
		}
		return instrance;
	}

	private Context context;

	/** 初始化切片管理者 */
	public void init(Activity activity) {
		main_middle_fragment = (RelativeLayout) activity
				.findViewById(R.id.main_middle_rlayout);
		context = main_middle_fragment.getContext();
		fragmentManager = ((FragmentActivity) activity)
				.getSupportFragmentManager();
	}

	public static BaseFragment nowFragment;// 记录当前界面
	public static BaseFragment lastFragment;

	/**
	 * 改变中间容器的切片方法 Class<? extends BaseFragment> targetFramentClass 构造器传类刷新切片
	 */
	public boolean changeMiddleView(
			Class<? extends BaseFragment> targetFramentClass) {
		// 判断当前界面与需要刷新的界面是否相同，直接调用class对象进行判断
		if (nowFragment != null && nowFragment.getClass() == targetFramentClass) {
			return false;// 如果相同直接方法false，不刷新
		}
		BaseFragment targetFrament = null;// 声明刷新目标切片
		try {
			Constructor<? extends BaseFragment> constructor = targetFramentClass
					.getConstructor(Context.class);// 获取目标切片构造器
			targetFrament = constructor.newInstance(context);// 传递上下文构造实例
			// 开启切片事务管理者
			fragmentTransaction = fragmentManager.beginTransaction();
			// 刷新切片到中间容器
			fragmentTransaction.replace(ConstantValue.MAIN_FRAGMENT_ID,
					targetFrament);
			// setTransition() 设置动画
			// fragmentTransaction.addToBackStack(null);// 加入栈顶
			nowFragment = targetFrament;// 记录当前界面
			fragmentTransaction.commitAllowingStateLoss();// 提交事务并指定界面失效，同时保存事务者
			changeTBshow(nowFragment.getFragmentId());// 通知观察者顶部底部导航灵动
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

	/** 切换中间容器并加入栈顶 */
	public boolean changeMiddleViewToStack(
			Class<? extends BaseFragment> targetFramentClass) {
		BaseFragment targetFrament = null;// 声明刷新目标切片
		if (lastFragment != nowFragment) {// 判断是否在返回事件中有所处理
			lastFragment = nowFragment;// 如果不相等代表不是放回后的Fragment，那么赋值
		}
		if (nowFragment != null && nowFragment.getClass() == targetFramentClass) {
			return false;// 如果相同直接方法false，不刷新
		}
		try {
			Constructor<? extends BaseFragment> constructor = targetFramentClass
					.getConstructor(Context.class);// 获取目标切片构造器
			targetFrament = constructor.newInstance(context);// 传递上下文构造实例
			// 开启切片事务管理者
			fragmentTransaction = fragmentManager.beginTransaction();
			fragmentTransaction.addToBackStack(null);// 加入栈顶
			// 刷新切片到中间容器
			fragmentTransaction.replace(ConstantValue.MAIN_FRAGMENT_ID,
					targetFrament);
			nowFragment = targetFrament;// 重新等于现在的Fragment
			// setTransition() 设置动画
			fragmentTransaction.commitAllowingStateLoss();
			changeTBshow(targetFrament.getFragmentId());// 提交事务并指定界面失效，同时保存事务者
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

	/** 通知观察者顶部底部导航灵动方法并传递切片唯一标识符 */
	public void changeTBshow(int fragmentid) {
		GeneralUilt.logTest(TAG, "id是" + fragmentid);
		setChanged();
		notifyObservers(fragmentid);
	}

	// public static View getNowView() {
	// return nowFragment.getView();
	// }
}
