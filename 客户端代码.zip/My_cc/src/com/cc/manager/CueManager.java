package com.cc.manager;

import com.cc.activity.MyTrueAndFalse;
import com.cc.activity.R;
import com.cc.activity.widget.AppMsg;
import com.cc.activity.widget.LoginDialog;
import com.cc.uilt.GeneralUilt;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;

/** 提示系统构造类 */
public class CueManager {
	private static final String TAG = "CueManager";
	/**
	 * @Title: 自定义LoginDialog开启和关闭方法
	 * @param context
	 * @throws
	 */
	static LoginDialog dialog;

	public static void showLoginDialog(Activity activity, Context context,
			int theme, MyTrueAndFalse reportback) {
		dialog = new LoginDialog(activity, context, theme, reportback);
		dialog.show();
		dialog.setAndFalse(reportback);
		GeneralUilt.logTest(TAG, "我开启了登录框");
	}

	public static void closeLoginDialog() {
		dialog.dismiss();
		GeneralUilt.logTest(TAG, "我关闭了登录框");
	}

	/**
	 * @Title: 网络设置提示框 再判断网络异常后调用
	 * @param context
	 *            上下文
	 * @throws
	 */
	public static void showNoNetWork(final Context context) {
		new AlertDialog.Builder(context)//
				.setIcon(R.drawable.isnet_icon)//
				.setTitle(R.string.app_name)//
				.setMessage("网络好像没有打开")//
				.setPositiveButton("设置", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						// 跳转到系统的网络设置界面
						Intent intent = new Intent();
						intent.setClassName("com.android.settings",
								"com.android.settings.WirelessSettings");
						context.startActivity(intent);
					}
				}).setNegativeButton("好", null).show();
	}

	private static AppMsg.Style style;// Toast样式声明

	/** 绿色顶部吐司 最后一个参数为显示位置的Gravity参数 ,默认为0顶部 */
	public static void showInfoToast(Activity context, String msg, int gravity) {
		style = new AppMsg.Style(AppMsg.LENGTH_SHORT, R.color.info);
		AppMsg appMsg = AppMsg.makeText(context, msg, style);
		if (gravity != 0) {
			appMsg.setLayoutGravity(gravity);
		}
		appMsg.show();
	}

	/** 蓝色顶部吐司 最后一个参数为显示位置的Gravity参数，默认为0顶部 */
	public static void showCustomToast(Activity context, String msg, int gravity) {
		style = new AppMsg.Style(AppMsg.LENGTH_SHORT, R.color.custom);
		AppMsg appMsg = AppMsg.makeText(context, msg, style);
		if (gravity != 0) {
			appMsg.setLayoutGravity(gravity);
		}
		appMsg.show();
	}
}
