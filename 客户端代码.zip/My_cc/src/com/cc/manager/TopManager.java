package com.cc.manager;

import java.io.IOException;
import java.util.Observable;
import java.util.Observer;
import org.apache.commons.lang3.StringUtils;

import com.capricorn.ArcMenu;
import com.cc.activity.MainActivity;
import com.cc.activity.R;
import com.cc.fragment.NewsBodyFragment;
import com.cc.fragment.NewsCollectFragment;
import com.cc.uilt.ConstantValue;
import com.cc.uilt.GeneralUilt;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @ClassName: TopManager l.hy
 * @Description: 顶部导航单例实现管理者
 * @date 2014-1-26 下午9:23:20 implements Observer
 */
@SuppressWarnings("unused")
public class TopManager implements Observer {
	private static final String TAG = "TopManager";// 调试常量

	/** 顶部通用导航控件声明 */
	private RelativeLayout top_GeneralRlayout;// 顶部通用导航容器
	private TextView top_general_text;
	private ArcMenu arcMenu;
	private Context context;
	/** 顶部导航管理者单例模式实现 */
	private static TopManager instrance;

	private TopManager() {
	}

	private Activity activity;

	public static TopManager getInstrance() {
		if (instrance == null) {
			instrance = new TopManager();
		}
		return instrance;
	}

	private FragmentMg mg;

	/** 初始化顶部管理者 */
	public void initTop(Activity activity) {
		this.activity = activity;
		mg = FragmentMg.getInstrance();
		top_GeneralRlayout = (RelativeLayout) activity
				.findViewById(R.id.top_general);
		context = top_GeneralRlayout.getContext();
		top_general_text = (TextView) activity
				.findViewById(R.id.top_general_textview);
	}

	private boolean saveNewsBody(View view) {

		return false;
	}

	/** 隐藏所有顶部导航不占据布局 */
	public void hideAllTop() {
		top_GeneralRlayout.setVisibility(View.GONE);
	}

	/** 显示通用顶部导航 */
	public void showGeneralTop() {
		top_GeneralRlayout.setVisibility(View.VISIBLE);
	}

	/** 设置通用顶部导航TextView的文字与图片 */
	public void setGeneralTextAndDrawable(int textResource, int tDrawableId) {
		top_general_text.setText(textResource);
		Drawable tDrawable = context.getResources().getDrawable(tDrawableId);
		top_general_text.setCompoundDrawablesWithIntrinsicBounds(tDrawable,
				null, null, null);
	}

	/**
	 * @Title: 设置顶部导航不带图片的文字效果
	 * @param textResource
	 */
	public void setGeneralText(int textResource) {
		top_general_text.setText(textResource);
		top_general_text.setCompoundDrawablesWithIntrinsicBounds(null, null,
				null, null);
	}

	/** 顶部导航按钮监听事件 */
	private int fragmentid;

	/** 顶部导航观察者实现，跟随中间容器变化灵动 */
	@Override
	public void update(Observable observable, Object data) {
		if (data != null && StringUtils.isNumeric(data.toString())) {
			fragmentid = Integer.parseInt(data.toString());
			switch (fragmentid) {
			case ConstantValue.NEWS_FRAGMENT_ID:// 观察到新闻界面的顶部灵动
				setGeneralTextAndDrawable(R.string.bottom_general_news_text,
						R.drawable.cc_bottom_news_d);// 设置图片与文字
				GeneralUilt.logTest(TAG, "切换到新闻界面");
				break;
			case ConstantValue.NEWS_COLLECT_FRAGMENT_ID:// 观察到天气界面的顶部灵动
				setGeneralTextAndDrawable(R.string.top_news_collect_text,
						R.drawable.christmas_star_collect);
				GeneralUilt.logTest(TAG, "新闻收藏界面");
				break;
			case ConstantValue.WEATHER_FRAGMENT_ID:// 观察到天气界面的顶部灵动
				setGeneralTextAndDrawable(R.string.bottom_general_weather_text,
						R.drawable.cc_bottom_weather_d);
				GeneralUilt.logTest(TAG, "切换到天气界面");
				break;
			}
		}
	}

}
