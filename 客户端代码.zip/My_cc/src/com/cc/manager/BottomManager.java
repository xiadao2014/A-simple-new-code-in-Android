package com.cc.manager;

import java.util.Observable;
import java.util.Observer;
import org.apache.commons.lang3.StringUtils;
import com.cc.activity.R;
import com.cc.fragment.NewsFragment;
import com.cc.fragment.WeatherFargment;
import com.cc.uilt.ConstantValue;
import com.cc.uilt.GeneralUilt;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;

/**
 * @ClassName: BottomManager l.hy
 * @Description: 单例形式的底部导航管理者
 * @date 2014-1-26 下午8:59:05
 */
@SuppressLint("CutPasteId")
@SuppressWarnings("unused")
public class BottomManager implements OnClickListener, Observer {
	private static final String TAG = "BottomManager";// 调试常量
	/** 底部通用导航控件声明 */
	private RelativeLayout bottomRelativeLayout;
	private RadioGroup bottomGeneralRadiogroup;// 底部通用单选导航容器
	private RadioButton bm_general_news;
	private RadioButton bm_general_weather;
	private RadioButton bm_general_store;
	private RadioButton bm_general_im;
	private RadioButton bm_general_gps;

	/** 构造管理者的单例模式 */
	private static BottomManager instrance;

	private BottomManager() {
	}

	public static BottomManager getInstrance() {
		if (instrance == null) {
			instrance = new BottomManager();
		}
		return instrance;
	}

	private Activity activity;
	private Context context;

	/** 初始化底部管理者 */
	public void initBottom(Activity activity, Context context) {
		this.activity = activity;
		this.context = context;
		bottomRelativeLayout = (RelativeLayout) activity
				.findViewById(R.id.main_bottom_rlayout);
		bottomGeneralRadiogroup = (RadioGroup) activity
				.findViewById(R.id.bottom_general_radiogroup);
		bm_general_news = (RadioButton) activity
				.findViewById(R.id.bottom_general_rg_news_rb);
		bm_general_weather = (RadioButton) activity
				.findViewById(R.id.bottom_general_rg_weather_rb);
		bm_general_store = (RadioButton) activity
				.findViewById(R.id.bottom_general_rg_store_rb);
		bm_general_im = (RadioButton) activity
				.findViewById(R.id.bottom_general_rg_im_rb);
		bm_general_gps = (RadioButton) activity
				.findViewById(R.id.bottom_general_rg_gps_rb);
		setListener();
		// intinewsBottom();
	}

	private View newsInclude;// 新闻界面底部容器
	private LinearLayout newsImgLayout;// 跟帖容器
	private ImageButton newsReplyImgBtn;// 跟帖按钮
	private ImageButton newsShareBtn;// 分享按钮
	private ImageButton newsCollectBtn;// 收藏按钮
	private LinearLayout newsEditLayout;// 发帖容器
	private EditText newReplyEdittext;// 发帖文本框
	private Button newReplyPost;// 提交发帖按钮

	/**
	 * @Title:初始化新闻底部导航，主要是在进入item条目后的底部显示
	 */
	public void intinewsBottom() {
		// 首先是newsInclude 底部中的新闻容器
		newsInclude = activity.findViewById(R.id.main_bottom_include);
		// 接着是被隐藏的发表评论文本框布局
		newsEditLayout = (LinearLayout) newsInclude
				.findViewById(R.id.news_reply_edit_layout);
		// 接着是默认被显示的ImgLayout跟帖视图
		newsImgLayout = (LinearLayout) newsInclude
				.findViewById(R.id.news_reply_img_layout);
		// 跟帖视图的imgbt，点击就转换到文本输入布局
		newsReplyImgBtn = (ImageButton) newsInclude
				.findViewById(R.id.news_reply_img_btn);
		newsReplyImgBtn.setOnClickListener(this);
		// 跟帖视图的分享img按钮
		newsShareBtn = (ImageButton) newsInclude
				.findViewById(R.id.news_share_btn);
		newsShareBtn.setOnClickListener(this);
		// 跟帖视图的收藏img按钮
		newsCollectBtn = (ImageButton) newsInclude
				.findViewById(R.id.news_collect_btn);
		newsCollectBtn.setOnClickListener(this);
		// 发帖视图的文本输入框
		newReplyEdittext = (EditText) newsInclude
				.findViewById(R.id.news_reply_edittext);
		// 发帖视图的发帖提交按钮
		newReplyPost = (Button) newsInclude.findViewById(R.id.news_reply_post);
		newReplyPost.setOnClickListener(this);
	}

	/** 显示新闻跟帖导航 */
	public void showNewsImgLayout() {
		newsEditLayout.setVisibility(View.GONE);
		newsImgLayout.setVisibility(View.VISIBLE);
	}

	/** 显示新闻发帖导航 */
	public void showNewsEidLayout() {
		newsImgLayout.setVisibility(View.GONE);
		newsEditLayout.setVisibility(View.VISIBLE);
	}

	/**
	 * @Title:通用导航监听初始化
	 */
	private void setListener() {
		bm_general_news.setOnClickListener(this);
		bm_general_weather.setOnClickListener(this);
		bm_general_store.setOnClickListener(this);
		bm_general_im.setOnClickListener(this);
		bm_general_gps.setOnClickListener(this);
	}

	/** 底部所有导航隐藏且不占用布局 */
	public void hideAllBottom() {
		bottomGeneralRadiogroup.setVisibility(View.GONE);
		newsInclude.setVisibility(View.GONE);
	}

	/** 底部通用单选导航显示方法 */
	public void showGeneralBottom() {
		hideAllBottom();
		bottomGeneralRadiogroup.setVisibility(View.VISIBLE);
	}

	/** 新闻跟帖底部导航显示方法 */
	public void showNewsIncludeBottom() {
		hideAllBottom();
		newsInclude.setVisibility(View.VISIBLE);
	}

	/** 底部导航按钮监听事件 获取中间管理者 */
	private FragmentMg FM = FragmentMg.getInstrance();
	private TopManager TM = TopManager.getInstrance();

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.bottom_general_rg_news_rb:
			GeneralUilt.logTest(TAG, "点击底部通用导航新闻按钮");
			FM.changeMiddleView(NewsFragment.class);// 调用管理者的刷新中间fragment方法
			// showGeneralBottom();
			// TM.in
			break;
		case R.id.bottom_general_rg_weather_rb:
			GeneralUilt.logTest(TAG, "点击底部通用导航天气按钮");
			FM.changeMiddleView(WeatherFargment.class);
			break;
		case R.id.bottom_general_rg_store_rb:
			GeneralUilt.logTest(TAG, "点击底部通用导航购物按钮");
			break;
		case R.id.bottom_general_rg_im_rb:
			GeneralUilt.logTest(TAG, "点击底部通用导航社交按钮");
			break;
		case R.id.bottom_general_rg_gps_rb:
			GeneralUilt.logTest(TAG, "点击底部通用导航导航按钮");
			break;
		case R.id.news_reply_img_btn:
			GeneralUilt.logTest(TAG, "你点击了跟帖按钮");
			showNewsEidLayout();
			break;
		}
	}

	/** 底部导航观察者实现，跟随中间容器变化灵动，底部导航来的观察者实现 */
	@Override
	public void update(Observable observable, Object data) {
		if (data != null && StringUtils.isNumeric(data.toString())) {
			int id = Integer.parseInt(data.toString());
			switch (id) {
			case ConstantValue.NEWS_FRAGMENT_ID:
				GeneralUilt.logTest(TAG, "中间容器改变切换至新闻界面");
				// showGeneralBottom();
				break;
			}
		}
	}
}
