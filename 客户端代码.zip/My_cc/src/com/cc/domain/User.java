package com.cc.domain;

import android.R.integer;

/**
 * @ClassName: User l.hy
 * @Description: 用户实体类
 * @date 2014-2-7 下午7:20:18
 */
public class User {
	private integer u_id;
	private String u_name, u_password;

	public User(String u_name, String u_password) {
		super();
		this.u_name = u_name;
		this.u_password = u_password;
	}

	public integer getU_id() {
		return u_id;
	}

	public void setU_id(integer u_id) {
		this.u_id = u_id;
	}

	public String getU_name() {
		return u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

	public String getU_password() {
		return u_password;
	}

	public void setU_password(String u_password) {
		this.u_password = u_password;
	}

	@Override
	public String toString() {
		return "User [u_id=" + u_id + ", u_name=" + u_name + ", u_password="
				+ u_password + "]";
	}

}
