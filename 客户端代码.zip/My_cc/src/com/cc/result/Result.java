package com.cc.result;

import java.util.ArrayList;
import java.util.LinkedList;

/** 结果集父类 */
public abstract class Result {
	protected String content;

	public abstract int getResultId();

	public Result(String content) {
		super();
		this.content = content;
	}

	public Result() {
		super();
	}

	public ArrayList<NewsResult> getNewsItemResult() {
		return null;
	}

	public ArrayList<LinkedList<NewsResult>> getNewsInitResult() {
		return null;
	}
}
