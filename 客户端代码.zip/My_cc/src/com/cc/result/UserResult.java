package com.cc.result;

/** 用户信息结果对象，用于接收用户的数据  */
public class UserResult extends Result {
	private int user_id;

	@Override
	public int getResultId() {
		return user_id;
	}

}
