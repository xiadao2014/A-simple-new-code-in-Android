package com.cc.result;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.cc.uilt.GeneralUilt;
import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.reflect.TypeToken;

/** 新闻数据包结果实体类 */
public class NewsResult extends Result {
	public NewsResult(String content) {
		super(content);
	}

	public NewsResult() {
		super();
	}

	@Expose
	private int newsitem_id;
	@Expose
	private String title_text;// 标头
	@Expose
	private String middle_text;// 摘要
	@Expose
	private String origin_text;// 时间
	@Expose
	private String img_url;// 图标

	@Override
	public int getResultId() {
		return newsitem_id;
	}

	public String getTitle_text() {
		return title_text;
	}

	public void setTitle_text(String title_text) {
		this.title_text = title_text;
	}

	public String getMiddle_text() {
		return middle_text;
	}

	public void setMiddle_text(String middle_text) {
		this.middle_text = middle_text;
	}

	public String getOrigin_text() {
		return origin_text;
	}

	public void setOrigin_text(String origin_text) {
		this.origin_text = origin_text;
	}

	public String getImg_url() {
		return img_url;
	}

	public void setImg_url(String img_url) {
		this.img_url = img_url;
	}

	@Override
	public String toString() {
		return "NewsItemResult [newsitem_id=" + newsitem_id + ", title_text="
				+ title_text + ", middle_text=" + middle_text
				+ ", origin_text=" + origin_text + ", img_url=" + img_url + "]";
	}

	@Override
	public ArrayList<NewsResult> getNewsItemResult() {
		String gsonDncodeStr = GeneralUilt.getGsonDncodeStr(content);
		ArrayList<NewsResult> list = new ArrayList<NewsResult>();
		Gson gson = new Gson();
		list = gson.fromJson(gsonDncodeStr, new TypeToken<List<NewsResult>>() {
		}.getType());
		return list;
	}

	@Override
	public ArrayList<LinkedList<NewsResult>> getNewsInitResult() {
		String gsonDncodeStr = GeneralUilt.getGsonDncodeStr(content);
		ArrayList<LinkedList<NewsResult>> list = new ArrayList<LinkedList<NewsResult>>();
		Gson gson = new Gson();
		list = gson.fromJson(gsonDncodeStr,
				new TypeToken<ArrayList<LinkedList<NewsResult>>>() {
				}.getType());
		return list;
	}
}
