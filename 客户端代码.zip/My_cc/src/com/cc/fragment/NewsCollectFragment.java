package com.cc.fragment;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import com.cc.activity.R;
import com.cc.activity.widget.ListViewCompat;
import com.cc.activity.widget.SlideView;
import com.cc.activity.widget.SlideView.OnSlideListener;
import com.cc.manager.CueManager;
import com.cc.manager.FragmentMg;
import com.cc.phone.db.CollectNews;
import com.cc.uilt.BitmapHelp;
import com.cc.uilt.ConstantValue;
import com.cc.uilt.GeneralUilt;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.DbUtils;
import com.lidroid.xutils.exception.DbException;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

/** 新闻收藏界面 */
@SuppressLint("ValidFragment")
public class NewsCollectFragment extends BaseFragment implements
		OnItemClickListener, OnClickListener, OnSlideListener {
	private static String TAG = "NewsCollectFragment";

	public NewsCollectFragment(Context context) {
		super(context);
	}

	public NewsCollectFragment() {
		super();
	}

	private View rootView;
	public static boolean isMessageItem = true;
	private LinearLayout ll;
	public static BitmapUtils bitmapUtils;
	private List<MessageItem> mMessageItems = new ArrayList<MessageItem>();
	private List<CollectNews> collectNewsAll;
	private ListViewCompat mListView;
	private SlideView mLastSlideViewWithStatusOn;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		if (rootView == null) {
			rootView = inflater.inflate(R.layout.news_collect_fragment_view,
					container, false);
		}
		// 填充view
		ll = (LinearLayout) rootView
				.findViewById(R.id.news_collect_linearlayout);
		mListView = (ListViewCompat) rootView
				.findViewById(R.id.collect_listview);
		mListView.setOnItemClickListener(this);
		// 缓存的rootView需要判断是否已经被加过parent，
		// 如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
		ViewGroup parent = (ViewGroup) rootView.getParent();
		if (parent != null) {
			parent.removeView(rootView);
		}
		return rootView;
	}

	@Override
	public void onResume() {
		init();// 聚焦的时候初始化
		super.onResume();
	}

	private FragmentMg mg;

	@SuppressWarnings("static-access")
	@Override
	public void onPause() {
		GeneralUilt.logTest(TAG, "收藏界面停止了");// 停止的时候，来做一些事情
		if (mg == null) {
			mg = FragmentMg.getInstrance();
		}
		mg.changeTBshow(mg.lastFragment.getFragmentId());// 首先通知顶部导航栏做改变
		mg.nowFragment = mg.lastFragment;// 接着我们返回了上个界面，那么就是说上个界面就是现在的界面了
		super.onPause();
	}

	static CollectAdapter adapter;
	private static DbUtils db;

	private void init() {
		db = DbUtils.create(context);// 创建数据库
		try {
			collectNewsAll = db.findAll(CollectNews.class);// 查找收藏数据库
			if (collectNewsAll != null) {
				ll.setVisibility(View.GONE);// 判断改变布局
				mListView.setVisibility(View.VISIBLE);
				initAdapterResult();
				adapter = new CollectAdapter();
				mListView.setAdapter(adapter);
			}
			if (collectNewsAll.size() == 0) {
				ll.setVisibility(View.VISIBLE);// 如果没有条目改变布局
				mListView.setVisibility(View.GONE);
			}

		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
	}

	/** 初始化适配器和缓存工具以及数据包添加 */
	private void initAdapterResult() {
		bitmapUtils = BitmapHelp.getBitmapUtils(getActivity()
				.getApplicationContext());
		bitmapUtils.configDefaultLoadingImage(R.drawable.now_loading);
		bitmapUtils.configDefaultLoadFailedImage(R.drawable.now_loading);
		bitmapUtils.configDefaultBitmapConfig(Bitmap.Config.RGB_565);
		if (isMessageItem) {
			for (int i = 0; i < collectNewsAll.size(); i++) {
				MessageItem item = new MessageItem();
				item.iconRes = collectNewsAll.get(i).getImgUrl();
				item.title = collectNewsAll.get(i).getTitleText();
				item.msg = collectNewsAll.get(i).getMiddleText();
				item.time = collectNewsAll.get(i).getOriginText();
				mMessageItems.add(item);
			}
		} else {
			isMessageItem = true;
		}
	}

	private static SlideView slideView;

	private class CollectAdapter extends BaseAdapter {
		private LayoutInflater mInflater;

		public CollectAdapter() {
			super();
			mInflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}

		@Override
		public int getCount() {
			return mMessageItems.size();
		}

		@Override
		public Object getItem(int position) {
			return mMessageItems.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			slideView = (SlideView) convertView;// 获取滑动删除的listview
			View collectItem = null;
			ViewHolder holder;
			if (slideView == null) {
				collectItem = mInflater.inflate(
						R.layout.news_collect_list_item_x, parent, false);
				slideView = new SlideView(getActivity());
				slideView.setContentView(collectItem);// 把我自己view添加到滑动删除的listview中
				holder = new ViewHolder(slideView);
				slideView.setOnSlideListener(NewsCollectFragment.this);
				slideView.setTag(holder);
			} else {
				holder = (ViewHolder) slideView.getTag();
			}
			MessageItem item = mMessageItems.get(position);
			item.slideView = slideView;
			item.slideView.shrink();
			bitmapUtils.display(holder.icon, item.iconRes);
			holder.title.setText(item.title);
			holder.msg.setText(item.msg);
			holder.time.setText(item.time);
			holder.deleteHolder.setOnClickListener(NewsCollectFragment.this);
			return slideView;
		}
	}

	// 缓存view与数据包
	public class MessageItem {
		public String iconRes;
		public String title;
		public String msg;
		public String time;
		public SlideView slideView;
	}

	private static class ViewHolder {
		public ImageView icon;
		public TextView title;
		public TextView msg;
		public TextView time;
		public ViewGroup deleteHolder;

		ViewHolder(View view) {
			icon = (ImageView) view.findViewById(R.id.news_collect_li_img);
			title = (TextView) view
					.findViewById(R.id.news_li_collect_title_text);
			msg = (TextView) view
					.findViewById(R.id.news_li_collect_middle_text);
			time = (TextView) view
					.findViewById(R.id.news_li_collect_origin_text);
			deleteHolder = (ViewGroup) view.findViewById(R.id.holder);
		}
	}

	// 当前ID
	@Override
	public int getFragmentId() {
		return ConstantValue.NEWS_COLLECT_FRAGMENT_ID;
	}

	private static int mposition;

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		mg = FragmentMg.getInstrance();
		mposition = position;
		NewsCollectBodyFragment.listResult = mMessageItems;
		NewsCollectBodyFragment.nowPosition = position;
		mg.changeMiddleViewToStack(NewsCollectBodyFragment.class);
		GeneralUilt.logTest(TAG, "我点击了条目");
	}

	@Override
	public void onSlide(View view, int status) {
		if (mLastSlideViewWithStatusOn != null
				&& mLastSlideViewWithStatusOn != view) {
			mLastSlideViewWithStatusOn.shrink();
		}

		if (status == SLIDE_STATUS_ON) {
			mLastSlideViewWithStatusOn = (SlideView) view;
		}
	}

	@Override
	public void onClick(View v) {
		if (v.getId() == R.id.holder) {// 点击删除view
			CollectNews collectNews = collectNewsAll.get(mposition);// 首先获得结果集包装的对象
			try {
				File f = new File(collectNews.getImgUrl());// 先删除sd卡上的图片文件
				if (f.exists()) {
					f.delete();
				}
				db.delete(collectNews);// 接着删除数据库的数据
				mMessageItems.remove(mposition);// 接着删除数据包的数据
				if (mMessageItems.size() == 0) {// 如果数据包为0时候，那么改变布局
					ll.setVisibility(View.VISIBLE);
					mListView.setVisibility(View.GONE);
					v.setVisibility(View.GONE);
				} else {
					adapter.notifyDataSetChanged();// 如果不是OK 我们刷新listview
				}
				GeneralUilt.logTest(TAG, "我点击了删除" + mposition);
			} catch (DbException e) {
				e.printStackTrace();
				CueManager.showInfoToast(getActivity(), "删除失败", 0);
			}
		}
	}
}
