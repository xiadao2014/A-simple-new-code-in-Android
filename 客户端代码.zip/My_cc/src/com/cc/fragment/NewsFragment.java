package com.cc.fragment;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnGenericMotionListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.LinearLayout.LayoutParams;

import com.capricorn.ArcMenu;
import com.cc.activity.R;
import com.cc.activity.adapter.ContentFragment;
import com.cc.ask.Ask;
import com.cc.ask.AskFactory;
import com.cc.manager.CueManager;
import com.cc.manager.FragmentMg;
import com.cc.result.NewsResult;
import com.cc.result.Result;
import com.cc.uilt.AskValue;
import com.cc.uilt.ConstantValue;
import com.cc.uilt.GeneralUilt;
import com.cc.uilt.TwitterRestClientUilt;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.viewpagerindicator.TabPageIndicator;
import com.viewpagerindicator.TabPageIndicator.OnTabReselectedListener;

/**
 * @ClassName: NewsFragment l.hy
 * @Description: 新闻主界面切片
 * @date 2014-2-5 下午3:14:54
 */
@SuppressLint("ValidFragment")
@SuppressWarnings("unused")
public class NewsFragment extends BaseFragment {
	public static List<LinkedList<NewsResult>> initResult;
	private static final String TAG = "NewsFragment";

	public NewsFragment(Context context) {
		super(context);
	}

	private static List<NewsResult> nowResult;// 当前的结果包
	private static ArcMenu arcMenu;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		if (nowResult == null) {
			nowResult = initResult.get(0);// 初始化结果包
		}
		arcMenu = (ArcMenu) getActivity().findViewById(R.id.top_arc_menu);
		super.onCreate(savedInstanceState);
	}

	public static List<NewsResult> getNowResult() {
		return nowResult;
	}

	private View mainview;// 缓存view
	private String[] CONTENT;// 标头

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		CONTENT = context.getResources().getStringArray(R.array.categories);
		if (mainview == null) { // 防止重复构建Fragment
			final Context contextTheme = new ContextThemeWrapper(getActivity(),
					R.style.Theme_PageIndicatorDefaults);
			LayoutInflater localinflater = inflater
					.cloneInContext(contextTheme);
			mainview = localinflater.inflate(R.layout.news_main_fragment,
					container, false);// 初始化新闻主界面，由TabPageIndicator和ViewPager组成
		}

		// 缓存的rootView需要判断是否已经被加过parent，
		// 如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
		ViewGroup parent = (ViewGroup) mainview.getParent();
		if (parent != null) {
			parent.removeView(mainview);
		}
		initArcMenu();
		initItemPager();
		return mainview;
	}

	@Override
	public int getFragmentId() {
		return ConstantValue.NEWS_FRAGMENT_ID;
	}

	/** 初始化新闻界面 */
	private void initItemPager() {
		FragmentPagerAdapter adapter = new WYNewsAdapter(
				getChildFragmentManager());// 嵌套fargment管理者
		ViewPager pager = (ViewPager) mainview.findViewById(R.id.pager);
		pager.setAdapter(adapter);// Fragment的Pager容器
		TabPageIndicator indicator = (TabPageIndicator) mainview
				.findViewById(R.id.indicator);// 新闻TabPage导航

		indicator.setOnPageChangeListener(new OnPageChangeListener() {
			@Override
			public void onPageSelected(int pagerposition) {
				nowResult = initResult.get(pagerposition);// 保存当前的结果包
				// GeneralUilt.logTest(TAG, "arg0" + pagerposition);
				// 记录当前的PAGER标识符
				ConstantValue.NOW_NEWS_PAGER_POSITION = pagerposition;
			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
			}
		});
		indicator.setViewPager(pager);
		indicator.setOnTabReselectedListener(null);
	}

	class WYNewsAdapter extends FragmentPagerAdapter {
		public WYNewsAdapter(FragmentManager fm) {
			super(fm);// 初始化嵌套管理者
		}

		@Override
		public Fragment getItem(int position) {
			// 初始化itemFrament,把结果发送过去
			return ContentFragment.newInstance(initResult.get(position),
					context, position);// 传递结果给初始化界面
		}

		@Override
		public CharSequence getPageTitle(int position) {
			return CONTENT[position % CONTENT.length].toUpperCase();// tab初始化
		}

		@Override
		public int getCount() {
			return CONTENT.length;
		}
	}

	private static final int[] GENERAL_TOP_MENU_DRAWABLES = {
			R.drawable.top_menu_bookmark, R.drawable.top_menu_collect,
			R.drawable.top_menu_menology, R.drawable.top_menu_seek,
			R.drawable.top_menu_share };
	private FragmentMg mg;

	private void initArcMenu() {
		mg = FragmentMg.getInstrance();
		final int itemCount = GENERAL_TOP_MENU_DRAWABLES.length;
		arcMenu.clearChildLayoutViews();// 自己写的一个简单方法，去除掉ArcMenu的子Menu
		for (int i = 0; i < itemCount; i++) {
			ImageView item = new ImageView(context);
			item.setImageResource(GENERAL_TOP_MENU_DRAWABLES[i]);
			final int position = i;
			arcMenu.addItem(item, new OnClickListener() {
				@Override
				public void onClick(View v) {
					GeneralUilt.logTest(TAG, "我点击topMenu" + position);
					switch (position) {// 点击的是书签，刷新到书签界面
					case 0:
						mg.changeMiddleViewToStack(NewsCollectFragment.class);
						break;
					case 1:// 点击的是收藏，判断中间容器是否为newBody
						if (ConstantValue.ISNEWSBODY) {
							NewsBodyFragment.saveNow();
						} else {
							CueManager.showInfoToast(getActivity(), "没有选择新闻", 0);
						}
						break;
					case 2:
						GeneralUilt.logTest(TAG, "在新闻界面点击了日历");
						break;
					case 3:
						GeneralUilt.logTest(TAG, "在新闻界面点击了搜索");
						break;
					case 4:
						GeneralUilt.logTest(TAG, "在新闻界面点击了分享");
						break;
					}
				}
			});
		}
	}
}
