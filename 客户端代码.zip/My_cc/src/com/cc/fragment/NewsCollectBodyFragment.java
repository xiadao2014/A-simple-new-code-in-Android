package com.cc.fragment;

import java.util.ArrayList;
import java.util.List;

import com.cc.activity.R;
import com.cc.fragment.NewsCollectFragment.MessageItem;
import com.cc.uilt.BitmapHelp;
import com.cc.uilt.ConstantValue;
import com.lidroid.xutils.BitmapUtils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/** 收藏内容的pagerBody */
@SuppressLint("ValidFragment")
public class NewsCollectBodyFragment extends BaseFragment {
	public static List<MessageItem> listResult;
	public static int nowPosition;
	private LayoutInflater mInflater;
	public static BitmapUtils bitmapUtils;
	private View mainview;// mainview
	private ViewPager pager;
	private PagerAdapter adapter;

	public NewsCollectBodyFragment(Context context) {
		super(context);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		//初始化图片加载
		bitmapUtils = BitmapHelp.getBitmapUtils(getActivity()
				.getApplicationContext());
		bitmapUtils.configDefaultLoadingImage(R.drawable.now_loading);
		bitmapUtils.configDefaultLoadFailedImage(R.drawable.now_loading);
		bitmapUtils.configDefaultBitmapConfig(Bitmap.Config.RGB_565);
		super.onCreate(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		if (mainview == null) {
			mainview = inflater.inflate(R.layout.news_collect_body_fragment,
					container, false);//得到mainbody
		}
		ViewGroup parent = (ViewGroup) mainview.getParent();
		if (parent != null) {
			parent.removeView(mainview);
		}
		pager = (ViewPager) mainview
				.findViewById(R.id.news_collect_body_viewpager);
		initAdapter(pager);//填充pager
		pager.setCurrentItem(nowPosition);
		return mainview;
	}

	@Override
	public void onPause() {
		NewsCollectFragment.isMessageItem = false;//如果我是从这返回去的，那么就让列表不能再次添加数据
		super.onPause();
	}

	/**  初始化适配器  */
	private void initAdapter(ViewPager pager) {
		mInflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);//得到打气筒
		List<View> viewResult = new ArrayList<View>();
		for (MessageItem tiem : listResult) {//填充View添加到list中
			View view = mInflater.inflate(R.layout.news_item_body, null);
			ImageView img = (ImageView) view.findViewById(R.id.news_body_imag);
			TextView title = (TextView) view.findViewById(R.id.news_body_title);
			TextView origin = (TextView) view
					.findViewById(R.id.news_body_origin);
			TextView middle = (TextView) view
					.findViewById(R.id.news_body_middle);
			bitmapUtils.display(img, tiem.iconRes);
			title.setText(tiem.title);
			origin.setText(tiem.msg);
			middle.setText(tiem.time);
			viewResult.add(view);
		}
		adapter = new MyViewPagerAdapter(viewResult);//传递listView
		pager.setAdapter(adapter);//加载适配器
	}

	public class MyViewPagerAdapter extends PagerAdapter {
		private List<View> mListViews;

		public MyViewPagerAdapter(List<View> mListViews) {
			this.mListViews = mListViews;// 构造方法，参数是我们的页卡，这样比较方便。
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView(mListViews.get(position));// 删除页卡
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) { // 这个方法用来实例化页卡
			container.addView(mListViews.get(position), 0);// 添加页卡
			return mListViews.get(position);
		}

		@Override
		public int getCount() {
			return mListViews.size();// 返回页卡的数量
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;// 官方提示这样写
		}
	}
	@Override
	public int getFragmentId() {
		return ConstantValue.NEWS_COLLECT_BODY_FRAGMENT_ID;//返回收藏界面Id
	}

}
