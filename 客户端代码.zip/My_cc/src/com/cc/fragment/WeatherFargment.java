package com.cc.fragment;

import com.cc.activity.R;
import com.cc.uilt.ConstantValue;
import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
/** 天气主界面 */
@SuppressLint("ValidFragment")
public class WeatherFargment extends BaseFragment {
	public WeatherFargment(Context context) {
		super(context);
	}

	private View rootView;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		if (rootView == null) {
			rootView = inflater.inflate(R.layout.weather_main_fragment,
					container, false);
		}
		// 缓存的rootView需要判断是否已经被加过parent，
		// 如果有parent需要从parent删除，要不然会发生这个rootview已经有parent的错误。
		ViewGroup parent = (ViewGroup) rootView.getParent();
		if (parent != null) {
			parent.removeView(rootView);
		}
		return rootView;
	}

	@Override
	public int getFragmentId() {
		return ConstantValue.WEATHER_FRAGMENT_ID;
	}

}
