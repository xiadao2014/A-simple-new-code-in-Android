package com.cc.fragment;

import java.util.List;
import com.cc.activity.R;
import com.cc.activity.adapter.NewsBodyPageAdapter;
import com.cc.activity.adapter.NewsResultListAdapterCall;
import com.cc.manager.CueManager;
import com.cc.phone.db.CollectNews;
import com.cc.uilt.ConstantValue;
import com.cc.uilt.FileUlits;
import com.cc.uilt.GeneralUilt;
import com.lidroid.xutils.DbUtils;
import com.lidroid.xutils.exception.DbException;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

/** 新闻主角儿，也是内容  */
@SuppressLint({ "ValidFragment", "NewApi" })
public class NewsBodyFragment extends BaseFragment {
	private static final String TAG = "NewsBodyFragment";
	private static Activity activity;//接收构造器
	private static Context mcontext;
	private static RelativeLayout fl;

	public NewsBodyFragment(Context context) {
		super(context);
	}

	public static int pagerCurrentItemId;//获得当前的pagerviewID
	private static NewsBodyPageAdapter adapter;//适配器

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		activity = getActivity();
		mcontext = context;
		GeneralUilt.logTest(TAG, "NewsBodyFragment" + this.getId());
		View inflate = inflater.inflate(R.layout.news_body_viewpager,
				container, false);//填充布局
		fl = (RelativeLayout) inflate
				.findViewById(R.id.news_body_viewpager_layout);
		ViewPager pager = (ViewPager) inflate
				.findViewById(R.id.news_body_viewpager);
		NewsResultListAdapterCall nowNewsCall = NewsResultListAdapterCall
				.getNowNewsCall();
		List<View> intiNewsBoddyPager = nowNewsCall.getNewsBoddyPager();
		adapter = new NewsBodyPageAdapter(intiNewsBoddyPager);//适配填充
		pager.setAdapter(adapter);
		pager.setCurrentItem(pagerCurrentItemId);
		return inflate;
	}

	@Override
	public int getFragmentId() {
		return ConstantValue.NEWS_FRAGMENT_BODY_ID;
	}

	@Override
	public void onStart() {
		ConstantValue.ISNEWSBODY = true;
		super.onStart();
	}

	@Override
	public void onStop() {
		ConstantValue.ISNEWSBODY = false;
		super.onStop();
	}

	public static void saveNow() {
		GeneralUilt.logTest(TAG, "我来保存了");//自己的保存方法
		boolean initCollectNewsImgSDc = FileUlits.initCollectNewsImgSDc();//获取数据库
		if (initCollectNewsImgSDc) {
			View childAt = adapter.getPrimaryItem();//获得当前view
			//取出来加载
			if (childAt.findViewById(R.id.news_body_imag) != null) {
				ImageView imview = (ImageView) childAt
						.findViewById(R.id.news_body_imag);
				imview.setDrawingCacheEnabled(true);
				Bitmap bmp = Bitmap.createBitmap(imview.getDrawingCache());
				imview.setDrawingCacheEnabled(false);
				byte[] bmpBytes = FileUlits.BitmapToBytes(bmp);
				String imgUrlstr = ConstantValue.COLLECT_NEWSIMG_PATH + "/"
						+ "newspager" + ConstantValue.NOW_NEWS_PAGER_POSITION
						+ "item" + pagerCurrentItemId + ".png";
				boolean writeBytesToSd = FileUlits.writeBytesToSd(bmpBytes,
						imgUrlstr);
				if (writeBytesToSd) {
					TextView titleview = (TextView) childAt
							.findViewById(R.id.news_body_title);
					TextView originview = (TextView) childAt
							.findViewById(R.id.news_body_origin);
					TextView middleview = (TextView) childAt
							.findViewById(R.id.news_body_middle);
					DbUtils db = DbUtils.create(activity);
					CollectNews collectNews = new CollectNews();
					collectNews.setImgUrl(imgUrlstr);
					collectNews.setTitleText(titleview.getText().toString());
					collectNews.setOriginText(originview.getText().toString());
					collectNews.setMiddleText(middleview.getText().toString());
					try {
						db.save(collectNews);
						showCollectSaveNewsBar();
					} catch (DbException e) {
						e.printStackTrace();
					}
				}
			} else {
				Toast.makeText(mcontext, "图片加载中，请稍候", Toast.LENGTH_SHORT)
						.show();
			}
		} else {
			CueManager.showInfoToast(activity, "sd卡有点问题哦!", 0);
		}
	}

	private static ImageView Collectiview;

	/**  加载一个星星的动画，也就是动画结束时删除就OK了  */
	public static void showCollectSaveNewsBar() {
		AlphaAnimation alphain = new AlphaAnimation(0.1f, 1.0f);
		alphain.setDuration(2000);
		Collectiview = new ImageView(activity);
		// view.setBackground(R.drawable.)
		// view.setAnimation(alphain);
		Collectiview.setBackgroundResource(R.drawable.christmas_star);
		RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
				RelativeLayout.LayoutParams.WRAP_CONTENT,
				RelativeLayout.LayoutParams.WRAP_CONTENT);
		layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT,
				RelativeLayout.TRUE);
		fl.addView(Collectiview, layoutParams);
		Collectiview.startAnimation(alphain);
		alphain.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation animation) {
			}

			@Override
			public void onAnimationRepeat(Animation animation) {
			}

			@Override
			public void onAnimationEnd(Animation animation) {
				fl.removeView(Collectiview);
			}
		});
	}

}
