package com.cc.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * @ClassName: BaseFragment l.hy
 * @Description: 切边父类抽取
 * @date 2014-2-5 下午3:15:35
 */
public abstract class BaseFragment extends Fragment {
	/** 切片View构造方法抽象化 */
	public abstract View onCreateView(LayoutInflater inflater,
			ViewGroup container, Bundle savedInstanceState);

	/** 切片上下文抽取 */
	protected Context context;

	/** 父类构造器，公有化保证在管理者中对所有子类可以进行class构造 */
	public BaseFragment(Context context) {
		super();
		this.context = context;
	}

	public BaseFragment() {
		super();
	}

	/** 切片唯一标识抽象化 */
	public abstract int getFragmentId();
}
