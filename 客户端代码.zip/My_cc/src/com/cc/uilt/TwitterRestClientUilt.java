package com.cc.uilt;

import com.cc.ask.Ask;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

/**
 * @ClassName: TwitterRestClientUilt
 * @Description:异步网络构造工具
 * @author lhy_cc
 * @date 2014-2-11 上午11:15:33
 */
public class TwitterRestClientUilt {
	/** 默认网络访问路径 *-代表工程名 */
	private static AsyncHttpClient client = new AsyncHttpClient();

	public static String getAbsoluteUrl(String actionMethod) {
		return ConstantValue.BASE_URL + actionMethod;
	}

	public static void get(String url, AsyncHttpResponseHandler responseHandler) {
		client.get(url, responseHandler);
	}

	public static void post(String actionMethod, RequestParams params,
			AsyncHttpResponseHandler responseHandler) {
		client.setTimeout(300000);
		client.post(getAbsoluteUrl(actionMethod), params, responseHandler);
	}

	public static void sendAsk(Ask targetAsk,
			AsyncHttpResponseHandler responseHandler) {
		String sendGsonStr = GeneralUilt.getGsonEncodeStr(targetAsk);
		String callAction = targetAsk.getAction() + targetAsk.getActionMethod();
		RequestParams params = new RequestParams();
		params.put(AskValue.BASE_PARAMS, sendGsonStr);
		TwitterRestClientUilt.post(callAction, params, responseHandler);
	}

}
