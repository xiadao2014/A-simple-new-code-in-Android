package com.cc.uilt;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import android.graphics.Bitmap;
import android.os.Environment;

/**  对于文件的帮助类 */
public class FileUlits {

	/** 初始化收藏新闻存储文件夹 */
	public static boolean initCollectNewsImgSDc() {
		File collectNewsImg = new File(getSDPath()
				+ ConstantValue.COLLECT_NEWSIMGFILE_NAME);
		if (!collectNewsImg.exists()) {
			try {
				collectNewsImg.mkdirs();
				ConstantValue.COLLECT_NEWSIMG_PATH = collectNewsImg
						.getAbsolutePath();
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		} else {
			ConstantValue.COLLECT_NEWSIMG_PATH = collectNewsImg
					.getAbsolutePath();
			return true;
		}
	}

	/** 获取sd卡绝对路径 */
	public static String getSDPath() {
		File sdDir = null;
		boolean sdCardExist = Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED); // 判断sd卡是否存在
		if (sdCardExist) {
			sdDir = Environment.getExternalStorageDirectory();// 获取跟目录
		}
		return sdDir.toString();
	}

	/** 将Bitmap转换成byte[] */
	public static byte[] BitmapToBytes(Bitmap bm) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bm.compress(Bitmap.CompressFormat.PNG, 100, baos);// png类型
		return baos.toByteArray();
	}

	// 写到sdcard中
	public static boolean writeBytesToSd(byte[] bs, String filePath) {
		try {
			FileOutputStream out = new FileOutputStream(new File(filePath));
			out.write(bs);
			out.flush();
			out.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
}
