package com.cc.uilt;

import com.cc.activity.R;

/**
 * @ClassName: ConstantValue l.hy
 * @Description: 常量类
 * @date 2014-2-5 下午3:25:06
 */
public class ConstantValue {
	/** 不存在标识符 */
	public static final String NOT_EXIST = "null";
	public static final String USER_TABLE_NAME = "cc_user";
	public static Boolean IS_USER = false;
	/** 刷新容器id常量 */
	public static final Boolean isTest = true;
	/** 代理商密码 */
	public static final String AGENT_PASSWORD = "9ab62a694d8bf6ced1fab6acd48d02f8";
	/** des加密用密钥 */
	public static final String DES_KEY = "9b2648fcdfbad80f";
	/** 刷新容器id常量 */
	public static final int MAIN_FRAGMENT_ID = R.id.main_middle_rlayout;
	/** 当前手机apn代理的ip */
	public static String PROXY_IP = "";
	public static int PROXY_PORT = 0;

	/** 保存用户信息的表名 */
	public static final String SHARED_USER = "cc_saveUser";

	/** 默认工程网络路径 *代表工程名 */
	public static final String BASE_URL = "http://10.0.2.2:8080/Mycc/";
	/** 中间main切片容器id常量 */
	public static final int NEWS_FRAGMENT_ID = 1001;
	public static final int WEATHER_FRAGMENT_ID = 1002;
	public static final int store_FRAGMENT_ID = 1003;
	public static final int IM_FRAGMENT_ID = 1004;
	public static final int GPS_FRAGMENT_ID = 1005;
	/** 新闻body子切片id */
	public static final int NEWS_FRAGMENT_BODY_ID = 100011;
	/** 新闻收藏界面id */
	public static final int NEWS_COLLECT_FRAGMENT_ID = 101113;
	public static final int NEWS_COLLECT_BODY_FRAGMENT_ID = 101114;
	/** 新闻body子切片是否显示 */
	public static boolean ISNEWSBODY = false;
	/** 新闻body子切片是否显示 */
	public static String COLLECT_NEWSIMGFILE_NAME = "/collectNewsImg";
	public static String COLLECT_NEWSIMG_PATH = "";
	public static Integer NOW_NEWS_PAGER_POSITION = 0;
	/** ios对话框按钮标识符 */
	public static final int IOS_DIALOG_GOOD_BUTTON_ID = 23756;
	public static final int IOS_DIALOG_NOT_BUTTON_ID = 23757;
}
