package com.cc.uilt;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.cc.activity.R;

public class FragmentUilt {
//	private static final String TAG = "FragmentUilt";
	/**  填充newsFramentTop导航栏  */
	public static void fallNewsFragmentTop(Context context, String[] lable,
			RadioGroup topGroup) {
		for (int i = 0; i < lable.length; i++) {
			RadioButton radioButton = (RadioButton) LayoutInflater
					.from(context).inflate(R.layout.news_radiobutton_item,
							topGroup, false);// 添加引用了style的radioButton.xml
			radioButton.setId(i);// 给id，不然没有单选效果
			radioButton.setText(lable[i]);// 设置文本
			topGroup.addView(radioButton);// 添加进去
			if (i == 0) {
				radioButton.setChecked(true);// 设置第一个为选中
				// radioGroup.getChildAt(1).setSelected(true); 也可以设置选中
			}
		}
	}
}
