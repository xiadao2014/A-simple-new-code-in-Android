package com.cc.uilt;

/**
 * @ClassName: ConstantValue l.hy
 * @Description: 常量类
 * @date 2014-2-5 下午3:25:06
 */
public class AskValue {

	/** 默认paramsKey值 */
	public static final String BASE_PARAMS = "Ask";

	/** 主访问 新闻Action标识符 */
	public static final String NEWS_BASE_ACTION = "News!";
	/** 主访问 用户Action标识符 */
	public static final String USER_BASE_ASK = "User!";
	/** 主访问 用户是否存在ActionMethod标识符 */
	public static final String USER_EXIST = "callUser";
	/** 新闻ActionMethod标识符 */
	public static final String NEWS_INIT = "callInitNews";
	public static final String NEWS_REFRESH = "callRefreshNewsItem";
	public static final String NEWS_BODY_METHOD = "callRefreshItme";

	/** 新闻客户端ITEM请求标示 */
	public static final int NEWS_ITEM_GIVEME = 100100;// 初始化
	public static final int NEWS_ITEM_GIVEME_1 = 100101;// Item叶子
	public static final int NEWS_ITEM_GIVEME_2 = 100102;
	public static final int NEWS_ITEM_GIVEME_3 = 100103;
	public static final int NEWS_ITEM_GIVEME_4 = 100104;
	public static final int NEWS_ITEM_GIVEME_5 = 100105;
	public static final int NEWS_ITEM_GIVEME_6 = 100106;
	public static final int NEWS_ITEM_GIVEME_7 = 100107;
	public static final int NEWS_ITEM_GIVEME_8 = 100108;
	public static final int NEWS_ITEM_GIVEME_9 = 100109;

}
