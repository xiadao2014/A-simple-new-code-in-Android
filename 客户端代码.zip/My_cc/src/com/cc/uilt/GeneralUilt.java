package com.cc.uilt;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import org.apache.commons.lang3.StringUtils;
import com.cc.activity.R;
import com.cc.domain.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.text.Selection;
import android.text.Spannable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;

/**
 * @ClassName: GeneralUilt
 * @Description: 通用工具类
 * @author lhy_cc
 * @date 2014-2-11 上午11:09:11
 */
public class GeneralUilt {
	/** 通用测试方法 */
	public static void logTest(String TAG, String msg) {
		if (ConstantValue.isTest) {
			Log.i(TAG, msg);
		}
	}

	/** 设置Edittext光标位置在最后 */
	public static void setEndEdittext(EditText aimEdi) {
		CharSequence text = aimEdi.getText();
		if (text instanceof Spannable) {
			Spannable spanText = (Spannable) text;
			Selection.setSelection(spanText, text.length());
		}
	}

	/** 转换对象包装为GsonEncodeStr，转换字符为EncodeUTF-8编码 ,用于发送处理 */
	public static String getGsonEncodeStr(Object o) {
		String gsonStr = getGsonStr(o);
		String encodeStr = null;
		try {
			encodeStr = URLEncoder.encode(gsonStr, "utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return encodeStr;
	}

	/** 转换对象成GsonStr */
	public static String getGsonStr(Object o) {
		Gson gson = new GsonBuilder().excludeFieldsWithoutExposeAnnotation() // 不导出实体中没有用@Expose注解的属性
				.enableComplexMapKeySerialization() // 支持Map的key为复杂对象的形式
				.serializeNulls().setDateFormat("yyyy-MM-dd HH:mm").create();// 时间转化为特定格式
		String gsonStr = gson.toJson(o);
		return gsonStr;
	}

	/** 解析GsonEncodeStr，转换字符正常字符串 ,用于接收处理 */
	public static String getGsonDncodeStr(String gsonEncodeStr) {
		String dncodeStr = null;
		try {
			dncodeStr = URLDecoder.decode(gsonEncodeStr, "utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return dncodeStr;
	}

	/**
	 * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
	 */
	public static int dip2px(Context context, float dpValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dpValue * scale + 0.5f);
	}

	/**
	 * 根据手机的分辨率从 px(像素) 的单位 转成为 dp
	 */
	public static int px2dip(Context context, float pxValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (pxValue / scale + 0.5f);
	}

	/** 添加一个"加载view" */
	public static View addProgressBar(LayoutInflater inflater, ViewGroup layout) {
		View progress = inflater.inflate(R.layout.progress, null);
		layout.addView(progress);
		return progress;
	}

	/** 删除一个"加载view" */
	public static void removeProgressBar(ViewGroup layout, View progress) {
		if (progress != null) {
			layout.removeView(progress);
		}
	}

	/** 震动当前View */
	public static void showShake(ViewGroup view, Context context) {
		Animation anim = AnimationUtils.loadAnimation(context,
				R.anim.shake_anim);
		view.startAnimation(anim);
	}

	public static void saveUesrShared(Context context, String tableName,
			User user) {
		SharedPreferences sp = context.getSharedPreferences(tableName,
				Context.MODE_PRIVATE);
		Editor edit = sp.edit();
		edit.putString("username", user.getU_name());
		edit.putString("password", user.getU_password());
		edit.commit();
	}

	public static boolean checkUesrShared(Context context) {
		SharedPreferences sp = context.getSharedPreferences(
				ConstantValue.USER_TABLE_NAME, Context.MODE_PRIVATE);
		String username = sp.getString("username", "");
		String password = sp.getString("password", "");
		if (StringUtils.isNotBlank(username)
				&& StringUtils.isNotBlank(password)) {
			return true;
		}
		return false;
	}

	/** 将Bitmap转换成byte[] */
	public static byte[] BitmapToBytes(Bitmap bm) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bm.compress(Bitmap.CompressFormat.PNG, 100, baos);// png类型
		return baos.toByteArray();
	}
}
