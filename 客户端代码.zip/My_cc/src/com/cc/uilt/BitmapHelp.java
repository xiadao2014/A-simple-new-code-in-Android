package com.cc.uilt;
import android.content.Context;
import com.lidroid.xutils.BitmapUtils;

/**
 * 异步图片加载缓存框架帮助类，其实就是一个单例的实现
 */
public class BitmapHelp {
	private BitmapHelp() {
	}

	private static BitmapUtils bitmapUtils;

	public static BitmapUtils getBitmapUtils(Context appContext) {
		if (bitmapUtils == null) {
			bitmapUtils = new BitmapUtils(appContext);
		}
		return bitmapUtils;
	}
}
