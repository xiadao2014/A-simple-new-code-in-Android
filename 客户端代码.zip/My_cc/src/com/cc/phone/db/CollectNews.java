package com.cc.phone.db;

import com.lidroid.xutils.db.annotation.Column;
import com.lidroid.xutils.db.annotation.Id;
import com.lidroid.xutils.db.annotation.Table;

/** 收藏界面数据库实体类 */
@Table(name = "collect_news")
public class CollectNews {
	@Id
	private int collect_news_id;
	@Column(column = "img_url")
	private String imgUrl;
	@Column(column = "title_text")
	private String titleText;
	@Column(column = "origin_text")
	private String originText;
	@Column(column = "middle_text")
	private String middleText;

	public CollectNews() {
		super();
	}

	public int getCollect_news_id() {
		return collect_news_id;
	}

	public void setCollect_news_id(int collect_news_id) {
		this.collect_news_id = collect_news_id;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getTitleText() {
		return titleText;
	}

	public void setTitleText(String titleText) {
		this.titleText = titleText;
	}

	public String getOriginText() {
		return originText;
	}

	public void setOriginText(String originText) {
		this.originText = originText;
	}

	public String getMiddleText() {
		return middleText;
	}

	public void setMiddleText(String middleText) {
		this.middleText = middleText;
	}

	@Override
	public String toString() {
		return "CollectNews [collect_news_id=" + collect_news_id + ", imgUrl="
				+ imgUrl + ", titleText=" + titleText + ", originText="
				+ originText + ", middleText=" + middleText + "]";
	}

}
