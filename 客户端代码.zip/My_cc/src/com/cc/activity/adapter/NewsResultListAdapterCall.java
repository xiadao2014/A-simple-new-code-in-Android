package com.cc.activity.adapter;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.w3c.dom.Text;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import com.cc.activity.R;
import com.cc.fragment.NewsBodyFragment;
import com.cc.fragment.NewsFragment;
import com.cc.manager.FragmentMg;
import com.cc.result.NewsResult;
import com.cc.uilt.GeneralUilt;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.ImageLoadingListener;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.PauseOnScrollListener;
import com.nostra13.universalimageloader.core.assist.SimpleImageLoadingListener;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.utils.StorageUtils;

/** 新闻界面网络加载适配器 */
/** 缓存加载适配器 */
@SuppressWarnings("unused")
public class NewsResultListAdapterCall implements OnItemClickListener {
	private static final String TAG = "NewsResultListAdapterCall";
	private Context context;// 构建LayoutInflater上下文
	private ListView newsItmelist;// 更改listView
	private LinkedList<NewsResult> result;// 结果数据集合
	private LayoutInflater inflater;// 填充器
	private DisplayImageOptions options;// Universal缓存加载框架
	private FragmentMg mg;// 中间容器切换
	private ImageLoader mImageLoader;//Universal加载器

	private NewsResultListAdapterCall() {
		super();
	}

	private static NewsResultListAdapterCall call;

	public static NewsResultListAdapterCall getNowNewsCall() {
		return call;// 单例
	}

	public NewsResultListAdapterCall(ListView newsItmelist, Context context,
			LinkedList<NewsResult> result) {
		super();
		call = this;// 初始化当然适配器
		this.newsItmelist = newsItmelist;// 获取需要加载的listView
		this.context = context;
		this.result = result;// 获取当前需要加载的结果包
		inflater = LayoutInflater.from(context);
		mg = FragmentMg.getInstrance();// 获取切换管理者
	}

	public static ImageListAdapter myImgAdapter;

	public static ImageListAdapter getImageListAdapter() {
		return myImgAdapter;
	}

	public void showNewsItemlist() {
		myImgAdapter = new ImageListAdapter();
		initDisplayOptions();// 初始化加载框架
		newsItmelist.setAdapter(myImgAdapter);// 适配器填充
		newsItmelist.setOnScrollListener(new PauseOnScrollListener(
				mImageLoader, true, false));
		newsItmelist.setOnItemClickListener(this);
	}

	private void initDisplayOptions() {
		options = new DisplayImageOptions.Builder()
				.showStubImage(R.drawable.now_loading)
				.imageScaleType(ImageScaleType.EXACTLY_STRETCHED)
				// 设置图片加载方式.EXACTLY缩放至目标大小
				// 设置正在加载图片
				// .showImageOnLoading(R.drawable.ic_stub) //1.8.7新增
				.showImageForEmptyUri(R.drawable.now_loading)
				// 设置加载失败图片
				.cacheInMemory().cacheOnDisc()
				.displayer(new RoundedBitmapDisplayer(20))// 设置图片角度,0为方形，360为圆角
				.displayer(new FadeInBitmapDisplayer(1000))// 设置渐显时间
				.build();

		mImageLoader = ImageLoader.getInstance();
		// 缓存目录
		// 有SD卡
		// path=/sdcard/Android/data/com.example.universalimageloadertest/cache
		// 无SD卡 path=/data/data/com.example.universalimageloadertest/cache
		File cacheDir = StorageUtils.getCacheDirectory(context);
	}

	class ImageListAdapter extends BaseAdapter {
		private ImageLoadingListener animateFirstListener = new AnimateFirstDisplayListener();

		private class ViewHolder {// 缓存Holder
			public ImageView news_li_img;
			public TextView news_li_title_text;//缓存控件
			public TextView news_li_origin_text;
			public TextView news_li_middle_text;
		}

		@Override
		public int getCount() {
			return result.size();
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(final int position, View convertView,
				ViewGroup parent) {
			View view = convertView;
			final ViewHolder holder;
			if (convertView == null) {
				view = inflater.inflate(R.layout.news_list_layout_item, parent,
						false);// 充气listItem
				holder = new ViewHolder();
				// 寻找控件
				holder.news_li_img = (ImageView) view
						.findViewById(R.id.news_li_img);
				holder.news_li_title_text = (TextView) view
						.findViewById(R.id.news_li_title_text);
				holder.news_li_origin_text = (TextView) view
						.findViewById(R.id.news_li_origin_text);
				holder.news_li_middle_text = (TextView) view
						.findViewById(R.id.news_li_middle_text);
				view.setTag(holder);
			} else {
				holder = (ViewHolder) view.getTag();
			}
			// 加载结果包到View
			holder.news_li_title_text.setText(result.get(position)
					.getTitle_text());
			holder.news_li_origin_text.setText(result.get(position)
					.getOrigin_text());
			holder.news_li_middle_text.setText("     "
					+ result.get(position).getMiddle_text());
			// 缓存加载图片
			mImageLoader.displayImage(result.get(position).getImg_url(),
					holder.news_li_img, options, animateFirstListener);
			return view;
		}
	}

	/** 加载监听器 */
	public static class AnimateFirstDisplayListener extends
			SimpleImageLoadingListener {

		public static final List<String> displayedImages = Collections
				.synchronizedList(new LinkedList<String>());

		@Override
		public void onLoadingComplete(String imageUri, View view,
				Bitmap loadedImage) {
			if (loadedImage != null) {
				ImageView imageView = (ImageView) view;
				boolean firstDisplay = !displayedImages.contains(imageUri);
				if (firstDisplay) {
					FadeInBitmapDisplayer.animate(imageView, 500);
					displayedImages.add(imageUri);//加载img
				}
			}
		}
	}

	/** 记录点击的Item */

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		NewsBodyFragment.pagerCurrentItemId = position - 1;// 注意要pager包下标与listView下标匹配
		GeneralUilt.logTest(TAG, NewsBodyFragment.pagerCurrentItemId+"");
		mg.changeMiddleViewToStack(NewsBodyFragment.class);// 切换至Body显示界面
	}

	/** 新闻大内容ViewPager填充listView获取 */
	public List<View> getNewsBoddyPager() {
		List<View> pagerlist = new ArrayList<View>();// View容器
		// 加载监听器
		ImageLoadingListener animateFirstListener = new AnimateFirstDisplayListener();
		List<NewsResult> nowResult = NewsFragment.getNowResult();// 获取当前结果包
		for (int i = 0; i < nowResult.size(); i++) {// 充气Pager
			View itembody = inflater.inflate(R.layout.news_item_body, null);
			ImageView imview = (ImageView) itembody
					.findViewById(R.id.news_body_imag);
			TextView titleview = (TextView) itembody
					.findViewById(R.id.news_body_title);
			TextView originview = (TextView) itembody
					.findViewById(R.id.news_body_origin);
			TextView middleview = (TextView) itembody
					.findViewById(R.id.news_body_middle);
			titleview.setText(nowResult.get(i).getTitle_text());
			originview.setText("  " + nowResult.get(i).getOrigin_text());
			middleview.setText("        " + nowResult.get(i).getMiddle_text());
			mImageLoader.displayImage(nowResult.get(i).getImg_url(), imview,
					options, animateFirstListener);// PagerItem图片加载
			pagerlist.add(itembody);
		}
		return pagerlist;
	}
}
