package com.cc.activity.adapter;

import java.util.ArrayList;
import java.util.LinkedList;
import com.cc.activity.R;
import com.cc.activity.adapter.NewsResultListAdapterCall.ImageListAdapter;
import com.cc.ask.Ask;
import com.cc.ask.AskFactory;
import com.cc.manager.CueManager;
import com.cc.result.NewsResult;
import com.cc.result.Result;
import com.cc.uilt.ConstantValue;
import com.cc.uilt.GeneralUilt;
import com.cc.uilt.TwitterRestClientUilt;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener;
import com.loopj.android.http.AsyncHttpResponseHandler;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

/** 新闻界面下拉刷新Fragment子pager */
public class ContentFragment extends Fragment {
	private static final String TAG = "ContentFragment";
	private LinkedList<NewsResult> result;
	private Context context;
	private int resultId;

	public static ContentFragment newInstance(LinkedList<NewsResult> result,
			Context context, int resultId) {
		ContentFragment fragment = new ContentFragment();
		fragment.result = result;// 获取处理好的数据
		fragment.context = context;
		fragment.resultId = resultId;
		return fragment;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	private PullToRefreshListView mPullRefreshListView;// 下拉刷新控件
	private NewsResultListAdapterCall call;// 缓存加载适配器

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View refreshflate = inflater.inflate(R.layout.news_pulltorefresh,
				container, false);// 首先填充下拉刷新listView
		mPullRefreshListView = (PullToRefreshListView) refreshflate
				.findViewById(R.id.pull_refresh_list);// 找到刷新控件
		mPullRefreshListView// 为下拉listview监听
				.setOnRefreshListener(new OnRefreshListener<ListView>() {
					@Override
					public void onRefresh(
							PullToRefreshBase<ListView> refreshView) {
						GeneralUilt.logTest(TAG, "我来刷新了");
						String label = DateUtils.formatDateTime(
								context.getApplicationContext(),
								System.currentTimeMillis(),
								DateUtils.FORMAT_SHOW_TIME
										| DateUtils.FORMAT_SHOW_DATE
										| DateUtils.FORMAT_ABBREV_ALL);// 判断下拉时间位置
						refreshView.getLoadingLayoutProxy()
								.setLastUpdatedLabel(label);// result.size()
						Ask ask = AskFactory.getRefreshNewsAsk(resultId,
								new String[] { result.size() + "" });// 获得news刷新请求
						TwitterRestClientUilt.sendAsk(ask,// 发送请求
								new AsyncHttpResponseHandler() {
									@Override
									public void onSuccess(String content) {
										if (content
												.equals(ConstantValue.NOT_EXIST)) {// 如果回来的是设置好的null
											CueManager.showInfoToast(
													getActivity(), "亲，已经是最新的了",
													0);// 提示
											mPullRefreshListView
													.onRefreshComplete();// 下拉条回去
										} else {
											GeneralUilt.logTest(TAG,
													"我接收到刷新数据了");
											Result Refreshresult = new NewsResult(
													content);// 接收到了 ok
											ArrayList<NewsResult> newsItemResult = Refreshresult
													.getNewsItemResult();// 转换
											for (NewsResult newsResult : newsItemResult) {
												result.addFirst(newsResult);// 数据置顶添加
											}
											ImageListAdapter imageListAdapter = NewsResultListAdapterCall
													.getImageListAdapter();// 获得list异步静态适配器
											imageListAdapter
													.notifyDataSetChanged();// ok通知更新
											if (call != null) {
												call.showNewsItemlist();// 如果拿到初始化
											}
											mPullRefreshListView
													.onRefreshComplete();
										}
									}
								});
					}
				});
		ListView actualListView = mPullRefreshListView.getRefreshableView();
		call = new NewsResultListAdapterCall(actualListView, getActivity(),
				result);// 新闻listview pager填充器声明
		call.showNewsItemlist();// 初始化listpager
		return refreshflate;// 返回下拉刷新listview
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
	}
}
