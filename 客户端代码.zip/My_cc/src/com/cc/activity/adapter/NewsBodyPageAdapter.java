package com.cc.activity.adapter;

import java.util.List;

import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;

/** 新闻内容界面适配器  */
public class NewsBodyPageAdapter extends PagerAdapter {
	private List<View> list;//结果view接收
	
	public NewsBodyPageAdapter(List<View> list) {
		super();
		this.list = list;
	}

	/** 返回布局或控件的个数 */
	@Override
	public int getCount() {
		return list.size();
	}

	private View mCurrentView;

	@Override
	public void setPrimaryItem(ViewGroup container, int position, Object object) {
		mCurrentView = (View) object;
	}

	public View getPrimaryItem() {
		return mCurrentView;
	}

	/** 销毁控件 */
	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		((ViewPager) container).removeView(list.get(position));
	}

	// /** 得到标头*/
	// @Override
	// public CharSequence getPageTitle(int position) {
	// return titles.get(position);
	// }
	/** 初始化容器 */
	@Override
	public Object instantiateItem(ViewGroup container, int position) {
		((ViewPager) container).addView(list.get(position));
		return list.get(position);
	}

	/** 判断是否关联 */
	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == arg1;
	}

}
