package com.cc.activity.widget;

import com.cc.activity.R;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.EditText;

/**
 * @ClassName: EditTextWithDel l.hy
 * @Description: 自定义文本输入框
 * @date 2014-2-8 下午10:33:14
 */
public class EditTextWithDel extends EditText {
	private final static String TAG = "EditTextWithDel";
	private Drawable imgInable, imgAble;// 声明EditTextWithDel子控件img(也就是清空小差
	private Context mContext;

	public EditTextWithDel(Context context) {
		super(context);
		mContext = context;
		init();
	}

	public EditTextWithDel(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		mContext = context;
		init();
	}

	public EditTextWithDel(Context context, AttributeSet attrs) {
		super(context, attrs);
		mContext = context;
		init();
	}

	/**
	 * @Title: 指定文本的背景效果资源文件id
	 * @param BackResource
	 *            资源文件id 通过次方法 ，我们可以在调用之前来更改文本框的背景
	 */
	private static int BackgroundResource = R.drawable.with_edittext_selector;

	public static void setbackResoId(int BackResource) {
		if (BackResource != 0) {
			BackgroundResource = BackResource;
		}
	}

	/**
	 * @Title:初始化自定义文本框
	 */
	private void init() {
		// 设置我的文本输入框的背景
		this.setBackgroundResource(BackgroundResource);
		// 获取小差图标
		imgInable = mContext.getResources().getDrawable(
				R.drawable.edittext_delete_gray);// 为小差赋值
		imgAble = mContext.getResources().getDrawable(
				R.drawable.edittext_delete);
		addTextChangedListener(new TextWatcher() {// 文本监听
			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {// 一但文本有内容，那么调用改变清除图片
				setDrawable();
			}
		});
		setDrawable();// 首先就把小差放进去
	}

	// 根据文本内容设置清除图片显示
	private void setDrawable() {
		Drawable drawable[] = getCompoundDrawables();
		if (length() < 1) {// 没有输入时的小差样式
			setCompoundDrawablesWithIntrinsicBounds(drawable[0], drawable[1],
					imgInable, drawable[3]);// 此做法可以兼容xml中的定义(建议不要使用null
		} else
			setCompoundDrawablesWithIntrinsicBounds(drawable[0], drawable[1],
					imgAble, drawable[3]);
	}

	// 清除图片点击事件，建立矩形
	private Rect rBounds;

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_UP && imgAble != null) {
			;// 如果屏幕被按上并且差不为空
			rBounds = imgAble.getBounds();// 得到和小差一样大的矩形
			final int x = (int) event.getX();// 得到当前点击位置
			final int y = (int) event.getY();
			// System.out.println("x:/y: "+x+"/"+y);
			// System.out.println("bounds: "+rBounds.left+"/"+rBounds.right+"/"+rBounds.top+"/"+rBounds.bottom);
			// check to make sure the touch event was within the bounds of the
			// drawable
//			System.out.println(x);
//			System.out.println(this.getRight() - rBounds.width());
			if (x >= (this.getRight() - rBounds.width()-76)// 如果点击位置横坐标大于总长度减去图片矩形宽即证明，点击横坐标在矩形内
					&& x <= (this.getRight() - this.getPaddingRight())// 并且不在边距中
					&& y >= this.getPaddingTop()+5// 同上
					&& y <= (this.getHeight() - this.getPaddingBottom()-10)) {
				// System.out.println("touch");
				this.setText("");// 判断成功即改变文本为空
				Log.i(TAG, "改变EditText文本形式成功");
				event.setAction(MotionEvent.ACTION_CANCEL);
				// use this to prevent the keyboard from coming up
			}
		}
		return super.onTouchEvent(event);
	}

	@Override
	protected void finalize() throws Throwable {
		super.finalize();
	}

}
