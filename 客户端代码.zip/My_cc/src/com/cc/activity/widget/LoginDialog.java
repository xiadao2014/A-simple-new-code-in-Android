package com.cc.activity.widget;

import org.apache.commons.lang3.StringUtils;

import com.cc.activity.MyTrueAndFalse;
import com.cc.activity.R;
import com.cc.ask.Ask;
import com.cc.ask.AskFactory;
import com.cc.domain.User;
import com.cc.manager.CueManager;
import com.cc.uilt.ConstantValue;
import com.cc.uilt.GeneralUilt;
import com.cc.uilt.TwitterRestClientUilt;
import com.loopj.android.http.AsyncHttpResponseHandler;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.view.View.OnClickListener;
import android.view.animation.AnimationUtils;

/**
 * @ClassName: LoginDialog
 * @Description: 登录Dialog
 * @author lhy_cc
 * @date 2014-2-11 上午11:12:34
 */
public class LoginDialog extends Dialog implements OnClickListener,
		OnTouchListener {
	private static final String TAG = "LoginDialog";
	private Activity activity;
	private Context context;
	private RelativeLayout login_Layout;
	private EditText username, password;
	private ImageView login_eye;
	private Button login_button;
	private CheckBox login_remember_box;
	private TextView register_text;
	@SuppressWarnings("unused")
	private MyTrueAndFalse reportback;
	private MyTrueAndFalse andFalse;

	public MyTrueAndFalse getAndFalse() {
		return andFalse;
	}

	public void setAndFalse(MyTrueAndFalse andFalse) {
		this.andFalse = andFalse;
	}

	/**
	 * @Title: 登录窗口构造器
	 * @param context
	 *            上下文
	 * @param theme
	 *            样式(一般之资源中的style文件)
	 */
	public LoginDialog(Activity activity, Context context, int theme,
			MyTrueAndFalse reportback) {
		super(context, theme);
		this.context = context;
		this.activity = activity;
		this.reportback = reportback;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.my_login_and_register);
		login_Layout = (RelativeLayout) findViewById(R.id.register_main_layout_shake);
		login_Layout.setAnimation(AnimationUtils.loadAnimation(context,
				R.anim.activity_dialog_in));
		inti();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_DOWN) {
			activity.finish();
		}
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * @Title:初始化登录窗口
	 */
	private void inti() {
		username = (EditText) findViewById(R.id.main_login_edittext_user);
		password = (EditText) findViewById(R.id.main_login_edittext_pass);
		login_eye = (ImageView) findViewById(R.id.main_login_password_eye_img);
		login_button = (Button) findViewById(R.id.main_login_button_land);
		login_remember_box = (CheckBox) findViewById(R.id.main_login_button_checkbox);
		register_text = (TextView) findViewById(R.id.main_login_register_textview);
		login_eye.setOnTouchListener(this);
		login_button.setOnClickListener(this);
		register_text.setOnClickListener(this);
	}

	public boolean isMemBox() {
		return login_remember_box.isChecked();
	}

	static User user;

	@Override
	public void onClick(View v) {
		String usernameStr = username.getText().toString().trim();
		String passwordStr = password.getText().toString().trim();
		if (StringUtils.isNotBlank(usernameStr)
				&& StringUtils.isNotBlank(passwordStr)) {
			user = new User(usernameStr, passwordStr);
			Ask userAsk = AskFactory.getIsUserAsk(new String[] { usernameStr,
					passwordStr });
			TwitterRestClientUilt.sendAsk(userAsk,
					new AsyncHttpResponseHandler() {
						@Override
						public void onSuccess(String content) {
							if (!content.equals(ConstantValue.NOT_EXIST)) {
								if (isMemBox()) {
									saveUser(user);
								}
								ConstantValue.IS_USER = true;
								CueManager.showCustomToast(activity, "欢迎回来", 0);
								andFalse.isTrue();
								loginDismiss();
							} else {
								Shake();
								username.setText("");
								password.setText("");
							}
						}
					});
		} else {
			Shake();
			username.setText("");
			password.setText("");
		}
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN: // 按下事件发生后执行代码的区域
			password.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
			GeneralUilt.logTest(TAG, "按下眼睛");
			break;
		case MotionEvent.ACTION_UP: // 松开事件发生后执行代码的区域
			password.setInputType(InputType.TYPE_CLASS_TEXT
					| InputType.TYPE_TEXT_VARIATION_PASSWORD);
			GeneralUilt.logTest(TAG, "松开眼睛");
			break;
		}
		GeneralUilt.setEndEdittext(password);// 最后我要设置光标位置在最后
		return false;
	}

	private void saveUser(User user) {
		GeneralUilt
				.saveUesrShared(context, ConstantValue.USER_TABLE_NAME, user);
	}

	private void Shake() {
		GeneralUilt.showShake(login_Layout, context);
	}

	private void loginDismiss() {
		this.dismiss();
	}

	@Override
	public void dismiss() {
		login_Layout.setAnimation(AnimationUtils.loadAnimation(context,
				R.anim.activity_dialog_out));// 加载一个退出的动画
		super.dismiss();
	}
}
