package com.cc.activity.widget;

import com.cc.activity.R;
import com.cc.uilt.ConstantValue;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/** ios对话控件 */
public class ActionSheet {

	public interface OnActionSheetSelected {
		void onClick(int whichButton);
	}

	private ActionSheet() {
	}

	/** 设置样式与控件的寻找 */
	public static Dialog showSheet(Context context,
			final OnActionSheetSelected actionSheetSelected,
			OnCancelListener cancelListener, String titleText) {
		final Dialog dlg = new Dialog(context, R.style.ActionSheet);
		LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		LinearLayout layout = (LinearLayout) inflater.inflate(
				R.layout.actionsheet, null);
		final int cFullFillWidth = 10000;
		layout.setMinimumWidth(cFullFillWidth);
		TextView mtitle = (TextView) layout.findViewById(R.id.sheet_title);
		mtitle.setText(titleText);
		TextView mContent = (TextView) layout.findViewById(R.id.sheet_content);
		TextView mCancel = (TextView) layout.findViewById(R.id.sheet_cancel);

		mContent.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				actionSheetSelected
						.onClick(ConstantValue.IOS_DIALOG_GOOD_BUTTON_ID);
				dlg.dismiss();
			}
		});
		// 回调接口
		mCancel.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				actionSheetSelected
						.onClick(ConstantValue.IOS_DIALOG_NOT_BUTTON_ID);
				dlg.dismiss();
			}
		});
		// 设置位置
		Window w = dlg.getWindow();
		WindowManager.LayoutParams lp = w.getAttributes();
		lp.x = 0;
		final int cMakeBottom = -1000;
		lp.y = cMakeBottom;
		lp.gravity = Gravity.BOTTOM;
		dlg.onWindowAttributesChanged(lp);
		dlg.setCanceledOnTouchOutside(false);
		if (cancelListener != null)
			dlg.setOnCancelListener(cancelListener);

		dlg.setContentView(layout);
		dlg.show();

		return dlg;
	}

}
