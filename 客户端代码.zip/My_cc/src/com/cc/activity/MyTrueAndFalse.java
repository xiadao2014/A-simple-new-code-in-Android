package com.cc.activity;

/**  一个简单的接口，用于各种回调事件 */
public interface MyTrueAndFalse {
	public void isTrue();
	public void isFalse();
}
