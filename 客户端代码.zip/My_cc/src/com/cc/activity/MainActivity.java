package com.cc.activity;

import static android.os.Build.VERSION.SDK_INT;
import static android.os.Build.VERSION_CODES.ICE_CREAM_SANDWICH;
import java.util.Date;
import com.cc.activity.R;
import com.cc.activity.adapter.NewsResultListAdapterCall;
import com.cc.activity.widget.ActionSheet;
import com.cc.activity.widget.ActionSheet.OnActionSheetSelected;
import com.cc.activity.widget.AppMsg;
import com.cc.ask.Ask;
import com.cc.ask.AskFactory;
import com.cc.fragment.NewsFragment;
import com.cc.manager.BottomManager;
import com.cc.manager.CueManager;
import com.cc.manager.FragmentMg;
import com.cc.manager.TopManager;
import com.cc.result.NewsResult;
import com.cc.result.Result;
import com.cc.uilt.AskValue;
import com.cc.uilt.ConstantValue;
import com.cc.uilt.GeneralUilt;
import com.cc.uilt.NetUilt;
import com.cc.uilt.TwitterRestClientUilt;
import com.loopj.android.http.AsyncHttpResponseHandler;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * @ClassName: MainActivity l.hy
 * @Description: 程序主界面，继承v4.FragmentActivity,实现对切片的管理
 * @date 2014-2-5 下午3:02:03
 */
public class MainActivity extends FragmentActivity implements OnCancelListener,
		OnActionSheetSelected, MyTrueAndFalse {
	private static final String TAG = "MainActivity";// 调试常量
	private TopManager topMg;// 头部导航栏管理者
	private BottomManager bottomMg;// 底部导航栏管理者
	private FragmentMg fragmentMg;// 中间容器管理者
	private RelativeLayout middleRl;// 中间根布局
	private View bar;// 等待加载view

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// setContentView(R.layout.activity_main);
		setContentView(R.layout.activity_main);
		ConstantValue.IS_USER = false;
	}

	@Override
	protected void onResume() {
		GeneralUilt.logTest(TAG, "我重新聚焦了");
		netWorkAndUserInit();// 一但我聚焦就立马判断是否有网络
		super.onResume();
	}

	/** 初始化当前网络状态 */
	private void netWorkAndUserInit() {
		GeneralUilt.logTest(TAG, "我来work了");
		middleRl = (RelativeLayout) findViewById(R.id.main_middle_rlayout);
		bar = GeneralUilt.addProgressBar(LayoutInflater.from(this), middleRl);
		boolean isNetwork = NetUilt.checkNet(this);// 获取网络信息
		if (isNetwork) {
			GeneralUilt.logTest(TAG, "网络可用");
			if (GeneralUilt.checkUesrShared(this) || ConstantValue.IS_USER) {
				mainActivityInit();// 如果已经登录那么初始化管理者
				// 获取网络数据，切换当新闻列表
				initNewsResult();
			} else {
				CueManager.showLoginDialog(this, this, R.style.DialogAppTheme,
						this);// 如果用户不存在那么show出登录界面,登录界面实例化，需要上下文，Activity，样式和一个回调接口
			}
		} else {
			GeneralUilt.logTest(TAG, "网络不可用");// 如果网络不可用，showios对话框
			TextView barText = (TextView) bar.findViewById(R.id.load_bar_text);
			barText.setText("亲 没有网络服务");
			ActionSheet.showSheet(MainActivity.this, MainActivity.this,
					MainActivity.this, "网络好像有问题哦，现在设置？");
		}
	}

	private void mainActivityInit() {
		topMg = TopManager.getInstrance();// 单例获取各管理者
		bottomMg = BottomManager.getInstrance();
		fragmentMg = FragmentMg.getInstrance();
		topMg.initTop(this);
		bottomMg.initBottom(this, this);
		fragmentMg.init(this);
		fragmentMg.addObserver(topMg);// 添加观察者
		fragmentMg.addObserver(bottomMg);// 添加观察者
		// GeneralUilt.logTest(TAG, "初始化成功");
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {// 重写返回键
		if (keyCode == KeyEvent.KEYCODE_BACK
				&& event.getAction() == KeyEvent.ACTION_DOWN) {// 如果点击返回
			if (this.getSupportFragmentManager().getBackStackEntryCount() == 0) {// 并且当前Fragment为栈中最后一个Fragment
				this.finish(); // finish当前activity
				NewsResultListAdapterCall.AnimateFirstDisplayListener.displayedImages
						.clear();// 清除图片缓存
				if (SDK_INT < ICE_CREAM_SANDWICH) {
					AppMsg.cancelAll(this);// 清理Toast
				}
				return true;// 完成操作
			}
		}
		return super.onKeyDown(keyCode, event);// 如果不满足条件调用系统返回即可
	}

	public boolean initNewsResult() {
		try {
			Ask targetAsk = AskFactory.getInitNewsAsk(
					AskValue.NEWS_ITEM_GIVEME, new Date(), null);// 通过请求工厂获取初始化新闻界面的请求
			TwitterRestClientUilt.sendAsk(targetAsk,// 调用发送方法进行发送
					new AsyncHttpResponseHandler() {
						@Override
						public void onSuccess(String content) {
							Result result = new NewsResult(content);// 一但成功返回，实例化结果对象，根据请求实例化相应的结果对象
							NewsFragment.initResult = result// 调用结果的自身的结果包装，并赋值给新闻界面的结果包
									.getNewsInitResult();
							GeneralUilt.removeProgressBar(middleRl, bar);// 关闭当前加载图标viwe
							// 中间管理者切换至新闻界面至此新闻界面初始化结束
							fragmentMg.changeMiddleView(NewsFragment.class);

						}

						@Override
						public void onFailure(Throwable error) {
							CueManager.showInfoToast(MainActivity.this,
									"(╯-╰)加载失败", 0);
						}
					});
		} catch (Exception e) {
			e.printStackTrace();
			CueManager.showInfoToast(MainActivity.this, "(╯-╰)加载失败", 0);
			return false;
		}
		return true;
	}

	@Override
	public void onClick(int whichButton) {
		switch (whichButton) {
		case ConstantValue.IOS_DIALOG_GOOD_BUTTON_ID:
			GeneralUilt.logTest(TAG, "点击了好");
			GeneralUilt.removeProgressBar(middleRl, bar);// 在设置网络对话框中点击了好，那么跳转设置
			Intent intent = new Intent("android.settings.WIRELESS_SETTINGS");
			startActivity(intent);
			break;

		case ConstantValue.IOS_DIALOG_NOT_BUTTON_ID:
			GeneralUilt.logTest(TAG, "点击了取消");
			CueManager.showInfoToast(MainActivity.this, "没有网络", 0);// 取消设置中间进度barText为没有网络
			break;
		}
	}

	@Override
	public void onCancel(DialogInterface dialog) {
		GeneralUilt.logTest(TAG, "点击了返回");
	}

	@Override
	protected void onDestroy() {
		if (SDK_INT < ICE_CREAM_SANDWICH) {
			AppMsg.cancelAll(this);// 清理Toast
		}
		super.onDestroy();
	}

	@Override
	public void isTrue() {
		mainActivityInit();// 处理login登录界面的返回接口
		initNewsResult();
	}

	@Override
	public void isFalse() {
	}

}
